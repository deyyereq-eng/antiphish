"""Local evidence that does not depend on a reachable trust-seal service."""

import re
from urllib.parse import urlsplit

from bs4 import BeautifulSoup

from analyzer.models import Finding, Page

PAYMENT_ROOTS = ("shaparak.ir",)
CARD = re.compile(r"card[-_ ]?(?:number|num|input)|\bpan\b|شماره\s*کارت|cc-number", re.I)
CVV = re.compile(r"cvv|cvc|رمز\s*(?:امنیتی|سه|چهار)|کد\s*اعتبار", re.I)
OTP = re.compile(r"\botp\b|otp[-_]|رمز\s*(?:دوم|پویا)|one.time.password", re.I)
PASSWORD = re.compile(r"pass(?:word)?|رمز\s*عبور", re.I)
SEAL_MARKER = re.compile(r"e[-_ ]?namad|اینماد|نماد\s*اعتماد", re.I)


def same_domain(host: str, root: str) -> bool:
    return host == root or host.endswith("." + root)


def payment_host(url: str) -> bool:
    host = (urlsplit(url).hostname or "").lower().rstrip(".")
    return any(same_domain(host, root) for root in PAYMENT_ROOTS)


def field_kinds(text: str) -> set[str]:
    return {
        name
        for name, pattern in (("card", CARD), ("cvv", CVV), ("otp", OTP), ("password", PASSWORD))
        if pattern.search(text)
    }


def input_context(tag, soup) -> str:
    pieces = [
        str(tag.get(key, ""))
        for key in ("id", "name", "type", "placeholder", "aria-label", "autocomplete")
    ]
    if tag.get("id"):
        pieces.extend(
            label.get_text(" ", strip=True)
            for label in soup.find_all("label", attrs={"for": tag["id"]})
        )
    parent_label = tag.find_parent("label")
    if parent_label:
        pieces.append(parent_label.get_text(" ", strip=True))
    # Only use a small nearest field wrapper, not the entire page or form.
    if tag.parent and len(tag.parent.find_all("input")) == 1:
        pieces.append(tag.parent.get_text(" ", strip=True)[:200])
    return " ".join(pieces)


def input_metadata(soup) -> dict[str, set[str]]:
    result = {}
    for tag in soup.find_all(["input", "textarea", "select"]):
        if str(tag.get("type", "")).lower() in {"hidden", "submit", "button", "checkbox", "radio"}:
            continue
        context = input_context(tag, soup)
        kinds = field_kinds(context)
        if tag.get("type") == "password" and not kinds:
            kinds.add("password")
        if tag.get("type") == "search" or re.search(r"\bsearch\b|جستجو", context, re.I):
            kinds.add("search")
        for value in (tag.get("id"), tag.get("name")):
            if value:
                result[str(value)] = kinds or {"input"}
    return result


def local_phishing_findings(page: Page) -> list[Finding]:
    soup = BeautifulSoup(page.text, "html.parser")
    groups = set()
    for tag in soup.find_all("input"):
        if str(tag.get("type", "")).lower() not in {
            "hidden",
            "checkbox",
            "radio",
            "submit",
            "button",
        }:
            groups.update(field_kinds(input_context(tag, soup)))
    if "card" in groups and "cvv" in groups and not payment_host(page.url):
        extra = " و رمز دوم/پویا" if "otp" in groups else ""
        return [
            Finding(
                "payment_form_outside_gateway",
                f"این صفحه شماره کارت و CVV2{extra} می‌خواهد، اما دامنهٔ صفحه زیرمجموعهٔ shaparak.ir نیست؛ نشانهٔ قوی درگاه تقلیدی است، نه حکم قطعی جعل اینماد.",
                "HTML inputs",
            )
        ]
    return []


def challenge_page(page: Page) -> bool:
    soup = BeautifulSoup(page.text, "html.parser")
    title = soup.title.get_text(" ", strip=True).lower() if soup.title else ""
    if title in {
        "just a moment...",
        "attention required! | cloudflare",
        "access denied",
        "security check",
    }:
        return True
    return bool(
        re.search(
            r"/cdn-cgi/challenge-platform/|cf-chl-widget|verify you are human", page.text, re.I
        )
    ) and not soup.find("input", type="password")
