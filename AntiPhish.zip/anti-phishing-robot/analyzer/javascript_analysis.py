"""Bounded, non-executing JavaScript AST and approximate inter-function data flow.

The analysis is flow-insensitive and conservative. Findings describe possible
source-to-network paths, not runtime proof or a complete JavaScript semantics.
"""

import base64
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit

import tree_sitter_javascript
from tree_sitter import Language, Parser

from analyzer.models import Finding
from analyzer.page_signals import field_kinds, payment_host

LANGUAGE = Language(tree_sitter_javascript.language())
FUNCTIONS = {
    "function_declaration",
    "function_expression",
    "arrow_function",
    "generator_function",
    "generator_function_declaration",
    "method_definition",
}
INPUT_EVENTS = {"input", "keydown", "keyup", "keypress", "beforeinput", "change", "paste"}
KEY_EVENTS = {"keydown", "keyup", "keypress"}
MAX_NODES = 60000
MAX_OPS = 500000
MAX_PASSES = 12
MAX_TEXT = 2 * 1024 * 1024
UNKNOWN = "@unknown"


@dataclass(frozen=True)
class Value:
    sources: frozenset[str] = frozenset()
    constants: frozenset[str] = frozenset()
    refs: frozenset[str] = frozenset()
    functions: frozenset[int] = frozenset()
    dom: frozenset[str] = frozenset()

    def merge(self, *others):
        values = (self,) + others
        parts = []
        for key in ("sources", "constants", "refs", "functions", "dom"):
            union = set().union(*(getattr(v, key) for v in values))
            if key == "constants" and (UNKNOWN in union or len(union) > 32):
                union = {UNKNOWN}
            parts.append(frozenset(sorted(union)[:32]))
        return Value(*parts)


EMPTY = Value()


@dataclass
class Scope:
    body: object
    parent: int
    document: int
    params: list[str] = field(default_factory=list)
    bindings: dict[str, Value] = field(default_factory=dict)
    returns: Value = EMPTY
    event: str = ""
    label: str = ""


@dataclass
class Analysis:
    findings: list[Finding] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    partial: bool = False
    imports: list[str] = field(default_factory=list)
    frame_urls: list[str] = field(default_factory=list)
    scripts: int = 0
    open_urls: list[str] = field(default_factory=list)
    decoded_programs: list[str] = field(default_factory=list)


class BudgetExceeded(Exception):
    pass


def unquote(text: str) -> str:
    text = text[1:-1]

    def replace(match):
        escaped = match.group(1)
        if escaped.startswith("u{"):
            return chr(int(escaped[2:-1], 16))
        if escaped.startswith(("u", "x")):
            return chr(int(escaped[1:], 16))
        return {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "v": "\v", "0": "\0"}.get(
            escaped, escaped
        )

    try:
        return re.sub(r"\\(u\{[0-9a-fA-F]{1,6}\}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)", replace, text)
    except (ValueError, OverflowError):
        return text


class Engine:
    def __init__(self, sources: list[tuple[str, str]], url: str, metadata: dict[str, set[str]]):
        self.url = url
        self.metadata = metadata
        self.sources = []
        self.names = []
        self.scopes = [Scope(None, 0, 0, label="global")]
        self.scope_ids = {}
        self.heap: dict[str, dict[str, Value]] = {}
        self.object_types = {}
        self.xhr_urls = {}
        self.result = Analysis(scripts=len(sources))
        self.ops = 0
        self.changed = False
        self.finding_keys = set()
        self.node_count = 0
        if sum(len(code.encode()) for _, code in sources) > MAX_TEXT:
            self.result.partial = True
            self.result.warnings.append("حجم کل جاوااسکریپت از سقف تحلیل ساختاری بیشتر بود.")
            sources = []
        for name, code in sources:
            self.add_document(name, code)

    def text(self, node, doc):
        return (
            self.sources[doc][node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            if node
            else ""
        )

    def add_document(self, name, code):
        doc = len(self.sources)
        raw = code.encode("utf-8")
        self.sources.append(raw)
        self.names.append(name)
        root = Parser(LANGUAGE).parse(raw).root_node
        if root.has_error:
            self.result.partial = True
            self.result.warnings.append("بخشی از جاوااسکریپت خطای نحوی داشت و کامل تحلیل نشد.")
        # Scripts share the global namespace. Each function gets a distinct lexical scope.
        self.scopes.append(Scope(root, 0, doc, label="script"))
        script_scope = len(self.scopes) - 1
        stack = [(root, script_scope)]
        while stack:
            node, owner = stack.pop()
            self.node_count += 1
            if self.node_count > MAX_NODES:
                self.result.partial = True
                self.result.warnings.append("تعداد گره‌های جاوااسکریپت از سقف منابع عبور کرد.")
                return
            if node.type in FUNCTIONS:
                params = node.child_by_field_name("parameters") or node.child_by_field_name(
                    "parameter"
                )
                names = []
                if params:
                    items = (
                        params.named_children if params.type == "formal_parameters" else [params]
                    )
                    names = []
                    for item in items:
                        target = (
                            item.child_by_field_name("left")
                            if item.type == "assignment_pattern"
                            else item
                        )
                        if target and target.type == "identifier":
                            names.append(self.text(target, doc))
                    if len(names) != len(items):
                        self.result.partial = True
                        self.result.warnings.append(
                            "پارامتر destructuring یا پیش‌فرض به‌طور کامل مدل نشده است."
                        )
                name_node = node.child_by_field_name("name")
                body = node.child_by_field_name("body")
                sid = len(self.scopes)
                self.scopes.append(
                    Scope(
                        body, owner, doc, names, label=self.text(name_node, doc)[:40] or "callback"
                    )
                )
                self.scope_ids[(doc, node.start_byte, node.end_byte)] = sid
                for param in names:
                    self.scopes[sid].bindings[param] = EMPTY
                if (
                    node.type in {"function_declaration", "generator_function_declaration"}
                    and name_node
                ):
                    self.put(owner, self.text(name_node, doc), Value(functions=frozenset({sid})))
                owner = sid
            if node.type not in {"string", "comment", "regex"}:
                stack.extend((child, owner) for child in reversed(node.named_children))

    def binding_scope(self, sid, name):
        while sid:
            if name in self.scopes[sid].bindings:
                return sid
            sid = self.scopes[sid].parent
        return 0

    def lookup(self, sid, name):
        return self.scopes[self.binding_scope(sid, name)].bindings.get(name, EMPTY)

    def put(self, sid, name, value, declare=False):
        if not name:
            return
        # Top-level script variables live in a common namespace across script files.
        if self.scopes[sid].body and self.scopes[sid].body.type == "program":
            sid = 0
        elif not declare:
            sid = self.binding_scope(sid, name)
        previous = self.scopes[sid].bindings.get(name, EMPTY)
        merged = previous.merge(value)
        if merged != previous:
            self.changed = True
        self.scopes[sid].bindings[name] = merged

    def store(self, ref, key, value):
        previous = self.heap.setdefault(ref, {}).get(key, EMPTY)
        merged = previous.merge(value)
        if merged != previous:
            self.changed = True
        self.heap[ref][key] = merged

    def property(self, value, key):
        result = EMPTY
        for ref in value.refs:
            props = self.heap.get(ref, {})
            if key == "*":
                for val in props.values():
                    result = result.merge(val)
            else:
                result = result.merge(props.get(key, EMPTY), props.get("*", EMPTY))
        return result

    def expand(self, value, seen=None):
        seen = set() if seen is None else seen
        result = value
        for ref in value.refs:
            if ref in seen or len(seen) > 64:
                continue
            seen.add(ref)
            for item in self.heap.get(ref, {}).values():
                result = result.merge(self.expand(item, seen))
        return result

    def symbol(self, node, sid):
        doc = self.scopes[sid].document
        if not node:
            return ""
        if node.type in {"identifier", "property_identifier", "this"}:
            return self.text(node, doc)
        if node.type == "member_expression":
            return (
                self.symbol(node.child_by_field_name("object"), sid)
                + "."
                + self.text(node.child_by_field_name("property"), doc)
            )
        if node.type == "subscript_expression":
            prop = self.eval(node.child_by_field_name("index"), sid)
            return (
                self.symbol(node.child_by_field_name("object"), sid)
                + "."
                + (next(iter(prop.constants)) if len(prop.constants) == 1 else "*")
            )
        return ""

    def seed_callback(self, function, values, event="", receiver=EMPTY):
        for target in function.functions:
            scope = self.scopes[target]
            if event:
                scope.event = event
            for name, value in zip(scope.params, values):
                self.put(target, name, value, declare=True)
            if receiver.dom:
                self.put(target, "this", receiver, declare=True)

    def read_input(self, obj, scope):
        kinds = set()
        for selector in obj.dom:
            key = selector.lstrip("#")
            match = re.search(r"\[name\s*=\s*['\"]?([^'\"\]]+)", selector)
            if match:
                key = match.group(1)
            kinds.update(self.metadata.get(key, field_kinds(key) or {"input"}))
        if not kinds:
            kinds.add("input")
        sources = {"input:" + kind for kind in kinds if kind != "search"}
        if "search" in kinds:
            sources.add("search")
        if scope.event in INPUT_EVENTS and "search" not in kinds:
            sources.add("live_input")
        return Value(sources=frozenset(sources))

    def emit_sink(self, node, sid, name, destination, payload):
        value = self.expand(payload).merge(self.expand(destination))
        sources = value.sources
        destination_values = self.expand(destination).constants
        host = urlsplit(self.url).hostname or ""
        dest_hosts = set()
        for item in destination_values:
            try:
                dest_hosts.add(urlsplit(urljoin(self.url, item)).hostname or "")
            except ValueError:
                continue
        cross_origin = bool(dest_hosts - {host, ""})
        matched = []
        if "keys" in sources:
            matched.append(
                (
                    "keyboard_to_network",
                    "دادهٔ کلیدهای فشرده‌شده از رویداد کیبورد به فراخوانی ارسال شبکه می‌رسد؛ احتمال کی‌لاگر تحت وب وجود دارد.",
                )
            )
        if sources & {"input:card", "input:cvv"} and not payment_host(self.url):
            matched.append(
                (
                    "card_data_to_network",
                    "اطلاعات حساس کارت از ورودی‌ها، از طریق متغیرها/توابع واسط، به ارسال شبکه روی صفحه‌ای خارج از دامنهٔ درگاه شاپرک می‌رسد.",
                )
            )
        if "clipboard" in sources:
            matched.append(
                (
                    "clipboard_to_network",
                    "محتوای کلیپ‌بورد خوانده شده و مسیر ارسال آن به شبکه دیده شد؛ نیازمند بررسی رضایت و هدف جمع‌آوری است.",
                )
            )
        if "input:password" in sources and (cross_origin or "api.telegram.org" in dest_hosts):
            matched.append(
                (
                    "password_to_external_host",
                    "مقدار ورودی رمز عبور به میزبان دیگری ارسال می‌شود؛ احتمال خروج اطلاعات حساس وجود دارد.",
                )
            )
        if "live_input" in sources and sources & {
            "input:input",
            "input:password",
            "input:card",
            "input:cvv",
            "input:otp",
        }:
            matched.append(
                (
                    "live_input_to_network",
                    "مقدار ورودی هنگام رویداد ورودی/کیبورد به شبکه می‌رسد؛ ممکن است ثبت زندهٔ اطلاعات باشد و باید کاربرد آن بازبینی شود.",
                )
            )
        for code, detail in matched:
            doc = self.scopes[sid].document
            location = f"{self.names[doc]}:{node.start_point.row + 1} → {name[:32]}"
            key = (code, location)
            if key not in self.finding_keys and len(self.result.findings) < 12:
                self.finding_keys.add(key)
                self.result.findings.append(Finding(code, detail, location))

    def eval(self, node, sid):
        if node is None:
            return EMPTY
        self.ops += 1
        if self.ops > MAX_OPS:
            raise BudgetExceeded
        scope = self.scopes[sid]
        doc = scope.document
        kind = node.type
        if kind in {"comment", "regex"}:
            return EMPTY
        if kind == "string":
            text = unquote(self.text(node, doc))
            return Value(constants=frozenset({text})) if len(text) < 8192 else EMPTY
        if kind == "import_statement":
            source = node.child_by_field_name("source")
            if source:
                self.result.imports.extend(self.eval(source, sid).constants)
            if any(
                child.type == "import_clause" and re.search(r"\bas\b|\*", self.text(child, doc))
                for child in node.named_children
            ):
                self.result.partial = True
                self.warn("نام مستعار/namespace در import به‌طور کامل مدل نشده است.")
            return EMPTY
        if kind in {"number", "true", "false", "null"}:
            return Value(constants=frozenset({self.text(node, doc)}))
        if kind in {"identifier", "this", "property_identifier"}:
            name = self.text(node, doc)
            value = self.lookup(sid, name)
            if (
                name in {"fetch", "XMLHttpRequest", "WebSocket", "Image", "eval", "Function"}
                and value == EMPTY
            ):
                return Value(constants=frozenset({"@" + name}))
            return value
        if kind in FUNCTIONS:
            target = self.scope_ids.get((doc, node.start_byte, node.end_byte))
            return Value(functions=frozenset({target})) if target is not None else EMPTY
        if kind in {"object", "array"}:
            ref = f"{doc}:{node.start_byte}"
            for index, child in enumerate(node.named_children):
                if child.type == "pair":
                    key_node = child.child_by_field_name("key")
                    key = self.text(key_node, doc)
                    if key_node and key_node.type == "string":
                        key = unquote(key)
                    self.store(ref, key, self.eval(child.child_by_field_name("value"), sid))
                elif child.type == "shorthand_property_identifier":
                    self.store(ref, self.text(child, doc), self.lookup(sid, self.text(child, doc)))
                elif child.type == "spread_element":
                    self.store(ref, "*", self.eval(child, sid))
                else:
                    self.store(ref, str(index), self.eval(child, sid))
            return Value(refs=frozenset({ref}))
        if kind in {"member_expression", "subscript_expression"}:
            symbol = self.symbol(node, sid)
            known = self.lookup(sid, symbol)
            if known != EMPTY:
                return known
            obj = self.eval(node.child_by_field_name("object"), sid)
            if kind == "member_expression":
                prop = self.text(node.child_by_field_name("property"), doc)
            else:
                indexes = self.eval(node.child_by_field_name("index"), sid).constants
                prop = next(iter(indexes)) if len(indexes) == 1 else "*"
            if symbol in {"location.href", "window.location.href", "document.location.href"}:
                return Value(constants=frozenset({self.url}))
            if symbol in {"window." + key for key in ("fetch", "eval", "Function")} | {
                "globalThis." + key for key in ("fetch", "eval", "Function")
            }:
                return Value(constants=frozenset({"@" + prop}))
            if prop == "value":
                return self.read_input(obj, scope)
            if prop in {"key", "keyCode", "which", "code"} and (
                "event:keyboard" in obj.sources or scope.event in KEY_EVENTS
            ):
                return Value(sources=frozenset({"keys"}))
            if prop in {"target", "currentTarget"}:
                return obj.merge(self.lookup(sid, "this"))
            if prop == "cookie" and symbol == "document.cookie":
                return Value(sources=frozenset({"cookie"}))
            return self.property(obj, prop).merge(Value(sources=obj.sources, dom=obj.dom))
        if kind == "variable_declarator":
            value = self.eval(node.child_by_field_name("value"), sid)
            name_node = node.child_by_field_name("name")
            if name_node.type == "identifier":
                self.put(sid, self.text(name_node, doc), value, declare=True)
            else:
                self.assign_pattern(name_node, value, sid)
            return value
        if kind in {"assignment_expression", "augmented_assignment_expression"}:
            left = node.child_by_field_name("left")
            value = self.eval(node.child_by_field_name("right"), sid)
            name = self.symbol(left, sid)
            if kind == "augmented_assignment_expression":
                value = value.merge(self.lookup(sid, name))
            if left.type == "identifier":
                self.put(sid, name, value)
            elif left.type in {"member_expression", "subscript_expression"}:
                obj = self.eval(left.child_by_field_name("object"), sid)
                key = name.rsplit(".", 1)[-1]
                for ref in obj.refs:
                    self.store(ref, key, value)
                if not obj.refs:
                    self.put(sid, name, value)
                if key.startswith("on") and key[2:] in INPUT_EVENTS | {"submit", "click"}:
                    event = key[2:]
                    self.seed_callback(
                        value,
                        [
                            Value(
                                sources=frozenset(
                                    {"event:keyboard" if event in KEY_EVENTS else "event:input"}
                                )
                            )
                        ],
                        event,
                        obj,
                    )
                if key in {"src", "href"}:
                    self.emit_sink(node, sid, "URL assignment", value, EMPTY)
            else:
                self.assign_pattern(left, value, sid)
            return value
        if kind == "return_statement":
            value = EMPTY
            for child in node.named_children:
                value = value.merge(self.eval(child, sid))
            updated = scope.returns.merge(value)
            if updated != scope.returns:
                self.changed = True
            scope.returns = updated
            return value
        if kind in {"call_expression", "new_expression"}:
            return self.call(node, sid)
        if kind == "template_string":
            value = EMPTY
            for child in node.named_children:
                if child.type == "string_fragment":
                    value = self.concatenate(
                        value, Value(constants=frozenset({self.text(child, doc)}))
                    )
                elif child.type == "template_substitution":
                    value = self.concatenate(value, self.eval(child, sid))
            return value
        if (
            kind == "binary_expression"
            and self.text(node.child_by_field_name("operator"), doc) == "+"
        ):
            return self.concatenate(
                self.eval(node.child_by_field_name("left"), sid),
                self.eval(node.child_by_field_name("right"), sid),
            )
        result = EMPTY
        for child in node.named_children:
            result = result.merge(self.eval(child, sid))
        return result

    def concatenate(self, left, right):
        constants = set()
        if UNKNOWN in left.constants or UNKNOWN in right.constants:
            constants.add(UNKNOWN)
        elif left.constants and right.constants:
            for a in sorted(left.constants)[:8]:
                for b in sorted(right.constants)[:8]:
                    if len(a + b) < 8192:
                        constants.add(a + b)
        else:
            constants.update(left.constants | right.constants)
        merged = left.merge(right)
        if len(constants) > 32:
            constants = {UNKNOWN}
        return Value(
            merged.sources,
            frozenset(sorted(constants)[:32]),
            merged.refs,
            merged.functions,
            merged.dom,
        )

    def assign_pattern(self, pattern, value, sid):
        if not pattern:
            return
        for child in pattern.named_children:
            if child.type in {"pair_pattern", "object_assignment_pattern"}:
                key = self.text(
                    child.child_by_field_name("key") or child.child_by_field_name("left"),
                    self.scopes[sid].document,
                )
                target = child.child_by_field_name("value") or child.child_by_field_name("left")
                derived = self.property(value, key)
                if key == "value":
                    derived = self.read_input(value, self.scopes[sid])
                self.put(sid, self.text(target, self.scopes[sid].document), derived, declare=True)
            elif child.type in {"identifier", "shorthand_property_identifier_pattern"}:
                name = self.text(child, self.scopes[sid].document)
                derived = (
                    self.read_input(value, self.scopes[sid])
                    if name == "value"
                    else self.property(value, name)
                )
                self.put(sid, name, derived, declare=True)

    def call(self, node, sid):
        scope = self.scopes[sid]
        function_node = node.child_by_field_name("function") or node.child_by_field_name(
            "constructor"
        )
        name = self.symbol(function_node, sid)
        function = self.eval(function_node, sid)
        arg_nodes = node.child_by_field_name("arguments")
        args = [self.eval(arg, sid) for arg in arg_nodes.named_children] if arg_nodes else []
        all_args = EMPTY
        for arg in args:
            all_args = all_args.merge(arg)
        obj_node = function_node.child_by_field_name("object") if function_node else None
        receiver = self.eval(obj_node, sid)
        method = name.rsplit(".", 1)[-1]
        if function_node and function_node.type == "import":
            method = "import"
        for builtin in ("fetch", "eval", "Function", "XMLHttpRequest", "WebSocket", "Image"):
            if "@" + builtin in function.constants:
                name = method = builtin
                break
        if method in {"eval", "Function"}:
            self.result.partial = True
            self.warn(
                "کد پویا eval/Function دیده شد؛ تحلیل ایستا ممکن است همه رفتارها را پوشش ندهد."
            )
            if args:
                for code in args[-1].constants:
                    if (
                        code != UNKNOWN
                        and code not in self.result.decoded_programs
                        and len(code) <= 8192
                        and len(self.result.decoded_programs) < 4
                    ):
                        self.result.decoded_programs.append(code)
        if node.type == "new_expression":
            ref = f"new:{scope.document}:{node.start_byte}"
            self.object_types[ref] = method
            if method == "WebSocket" and args:
                self.xhr_urls[ref] = args[0]
            if method == "FormData" and args:
                self.store(
                    ref,
                    "*",
                    Value(
                        sources=frozenset(
                            {
                                "input:" + kind
                                for kinds in self.metadata.values()
                                for kind in kinds
                                if kind != "search"
                            }
                        )
                    ),
                )
            return Value(refs=frozenset({ref}))
        if method in {
            "getElementById",
            "querySelector",
            "querySelectorAll",
            "getElementsByName",
        } or name in {"$", "jQuery"}:
            return Value(dom=frozenset(args[0].constants if args else ()))
        if method == "val" and not args:
            return self.read_input(receiver, scope)
        if method in {"serialize", "serializeArray"}:
            return Value(
                sources=frozenset(
                    {
                        "input:" + kind
                        for kinds in self.metadata.values()
                        for kind in kinds
                        if kind != "search"
                    }
                )
            )
        if method in {"addEventListener", "on", "bind"} and args:
            events = args[0].constants
            event = next((x for x in sorted(events) if x in INPUT_EVENTS | {"submit", "click"}), "")
            if event:
                callback = args[-1]
                self.seed_callback(
                    callback,
                    [
                        Value(
                            sources=frozenset(
                                {"event:keyboard" if event in KEY_EVENTS else "event:input"}
                            )
                        )
                    ],
                    event,
                    receiver,
                )
            return EMPTY
        if method in INPUT_EVENTS and args and args[0].functions:
            self.seed_callback(
                args[0],
                [
                    Value(
                        sources=frozenset(
                            {"event:keyboard" if method in KEY_EVENTS else "event:input"}
                        )
                    )
                ],
                method,
                receiver,
            )
            return EMPTY
        if method in {"forEach", "map", "filter"} and args:
            self.seed_callback(args[0], [self.expand(receiver)], receiver=receiver)
        if method in {"then", "catch"} and args:
            self.seed_callback(args[0], [self.expand(receiver)])
        if method == "getCurrentPosition" and args:
            self.seed_callback(args[0], [Value(sources=frozenset({"geolocation"}))])
            self.warn("صفحه درخواست موقعیت جغرافیایی دارد؛ وجود این قابلیت به‌تنهایی بدافزار نیست.")
        if method == "getUserMedia":
            self.warn("صفحه درخواست دسترسی دوربین/میکروفون دارد؛ هدف و رضایت کاربر باید بررسی شود.")
        if method == "readText" and "clipboard" in name:
            return Value(sources=frozenset({"clipboard"}))
        if method in {"append", "set", "push", "unshift"} and args:
            # Preserve collection aliases as values move through helper functions.
            values = args[1:] if method in {"append", "set"} else args
            for ref in receiver.refs:
                for val in values:
                    self.store(ref, "*", val)
            return receiver
        if method == "open" and len(args) >= 2:
            for ref in receiver.refs:
                self.xhr_urls[ref] = args[1]
        if name in {"window.open", "open"} and args:
            self.result.open_urls.extend(args[0].constants)
        if name in {"fetch", "window.fetch", "globalThis.fetch"}:
            payload = self.property(args[1], "body") if len(args) > 1 else EMPTY
            self.emit_sink(node, sid, "fetch", args[0] if args else EMPTY, payload)
        elif method == "sendBeacon" and len(args) > 1:
            self.emit_sink(node, sid, "sendBeacon", args[0], args[1])
        elif method == "send" and args:
            destination = EMPTY
            for ref in receiver.refs:
                destination = destination.merge(self.xhr_urls.get(ref, EMPTY))
            self.emit_sink(node, sid, "send", destination, args[0])
        elif (
            name in {"$.post", "jQuery.post", "axios.post", "axios.put", "axios.patch"}
            and len(args) > 1
        ):
            self.emit_sink(node, sid, name, args[0], args[1])
        elif name in {"$.ajax", "jQuery.ajax", "axios"} and args:
            self.emit_sink(
                node, sid, name, self.property(args[0], "url"), self.property(args[0], "data")
            )
        elif name in {"$.get", "jQuery.get", "axios.get"} and args:
            payload = args[1] if len(args) > 1 else EMPTY
            self.emit_sink(node, sid, name, args[0], payload)
        for target in function.functions:
            self.seed_callback(Value(functions=frozenset({target})), args)
        returned = EMPTY
        for target in function.functions:
            returned = returned.merge(self.scopes[target].returns)
        if method in {"import", "require"} and args:
            self.result.imports.extend(sorted(args[0].constants))
            if not args[0].constants:
                self.result.partial = True
                self.warn("مسیر import پویا قابل تعیین نبود.")
        if method == "atob" and args:
            constants = set()
            for val in args[0].constants:
                try:
                    decoded = base64.b64decode(val, validate=True).decode("utf-8")
                    if len(decoded) < 8192:
                        constants.add(decoded)
                except (ValueError, UnicodeError):
                    pass
            return Value(sources=self.expand(args[0]).sources, constants=frozenset(constants))
        if name == "String.fromCharCode" and args:
            try:
                constants = frozenset({"".join(chr(int(next(iter(a.constants)))) for a in args)})
                return Value(constants=constants)
            except (ValueError, StopIteration, OverflowError):
                return EMPTY
        # Do not invent input-tainted return values for logging, HTTP responses,
        # or known helpers which have no return statement.
        if function.functions:
            return returned
        if name in {
            "fetch",
            "window.fetch",
            "globalThis.fetch",
            "$.post",
            "$.get",
            "$.ajax",
            "jQuery.post",
            "jQuery.get",
            "jQuery.ajax",
            "axios",
            "axios.post",
            "axios.put",
            "axios.patch",
            "axios.get",
        } or method in {"sendBeacon", "send", "open"}:
            return EMPTY
        if name.startswith("console."):
            return EMPTY
        if method in {"then", "catch", "forEach", "map", "filter"}:
            callback_return = EMPTY
            for callback in args:
                for target in callback.functions:
                    callback_return = callback_return.merge(self.scopes[target].returns)
            return self.expand(receiver).merge(callback_return)
        if name in {
            "JSON.stringify",
            "JSON.parse",
            "encodeURIComponent",
            "encodeURI",
            "decodeURIComponent",
            "decodeURI",
            "btoa",
            "String",
            "Number",
            "parseInt",
            "parseFloat",
        } or method in {
            "trim",
            "replace",
            "replaceAll",
            "join",
            "split",
            "substring",
            "substr",
            "slice",
            "toString",
            "toLowerCase",
            "toUpperCase",
            "concat",
            "charCodeAt",
        }:
            return self.expand(receiver).merge(self.expand(all_args))
        sensitive = self.expand(all_args).sources | self.expand(receiver).sources
        if sensitive & {
            "keys",
            "clipboard",
            "live_input",
            "input:password",
            "input:card",
            "input:cvv",
            "input:otp",
        }:
            self.result.partial = True
            self.warn(
                "حداقل یک تابع بیرونی با دادهٔ حساس قابل مدل‌سازی نبود؛ پوشش مسیر داده ناقص است."
            )
        return EMPTY

    def warn(self, text):
        if text not in self.result.warnings:
            self.result.warnings.append(text)

    def run(self):
        try:
            for _ in range(MAX_PASSES):
                self.changed = False
                for sid in range(1, len(self.scopes)):
                    scope = self.scopes[sid]
                    value = self.eval(scope.body, sid)
                    if scope.body and scope.body.type not in {"statement_block", "program"}:
                        merged = scope.returns.merge(value)
                        if merged != scope.returns:
                            self.changed = True
                        scope.returns = merged
                if not self.changed:
                    break
            else:
                self.result.partial = True
                self.warn("تحلیل مسیر داده به سقف تعداد تکرار رسید؛ پوشش ممکن است ناقص باشد.")
        except (BudgetExceeded, RecursionError):
            self.result.partial = True
            self.warn("تحلیل ساختاری به سقف منابع رسید؛ بخشی از کد بررسی نشد.")
        self.result.imports = list(dict.fromkeys(self.result.imports))
        self.result.open_urls = list(dict.fromkeys(self.result.open_urls))
        return self.result


def analyze_sources(sources, url="https://example.test/", metadata=None) -> Analysis:
    try:
        engine = Engine(sources, url, metadata or {})
        return engine.run()
    except (RecursionError, ValueError):
        return Analysis(partial=True, warnings=["ساختار جاوااسکریپت قابل تحلیل کامل نبود."])
