"""Combine local phishing evidence with independent trust-seal verification."""

import re
from urllib.parse import parse_qs, urljoin, urlsplit

from bs4 import BeautifulSoup

from analyzer.http_client import Fetcher, FetchError, normalize_url
from analyzer.javascript_analysis import unquote
from analyzer.models import CheckResult, Finding, Page, Status
from analyzer.page_signals import SEAL_MARKER, local_phishing_findings

TRUST_HOST = "trustseal.enamad.ir"
DOMAIN = re.compile(r"(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})(?::\d+)?(?:/[^\s<>]*)?", re.I)
OPEN_URL = re.compile(r"(?:window\s*\.\s*)?open\s*\(\s*((['\"])(?:\\.|(?!\2)[\s\S])*?\2)", re.I)


def host_matches(text: str, host: str) -> bool:
    host = host.removeprefix("www.")
    return bool(re.search(r"(?<![\w.-])(?:www\.)?" + re.escape(host) + r"(?![\w.-])", text, re.I))


def reference_domains(html: str) -> set[str]:
    """Read domain fields, never incidental mentions in scripts, examples, or footer text."""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup.find_all(["script", "style"]):
        tag.decompose()
    candidates = []
    for tag in soup.find_all(True):
        marker = " ".join((str(tag.get("id", "")), " ".join(tag.get("class", []))))
        if re.search(
            r"(?:lbl|txt|website|site|domain).*domain|\bdomain\b|website[-_]?(?:url|address)",
            marker,
            re.I,
        ):
            candidates.append(tag.get_text(" ", strip=True))
    text = soup.get_text(" ", strip=True)
    for match in re.finditer(
        r"(?:دامنه(?:\s*(?:ثبت.?شده|وب.?سایت))?|آدرس\s*(?:وب\s*)?سایت|website|domain)\s*[:：]?\s*((?:https?://)?(?:[a-z0-9-]+\.)+[a-z]{2,}[^\s]*)",
        text,
        re.I,
    ):
        candidates.append(match.group(1))
    result = set()
    for candidate in candidates:
        for match in DOMAIN.finditer(candidate):
            result.add(match.group(1).lower().removeprefix("www.").rstrip("."))
    return result


def collect_seals(page: Page, script_urls=()):
    soup = BeautifulSoup(page.text, "html.parser")
    base = soup.find("base", href=True)
    base_url = urljoin(page.url, str(base["href"])) if base else page.url
    candidates = []
    badges = []
    offline = []
    for image in soup.find_all(["img", "svg", "object"]):
        marker = " ".join(
            str(image.get(key, ""))
            for key in ("src", "data-src", "alt", "title", "id", "class", "aria-label", "data")
        )
        if not SEAL_MARKER.search(marker):
            continue
        badges.append(image)
        anchor = image.find_parent("a")
        targets = []
        if (
            anchor
            and anchor.get("href")
            and anchor["href"] not in {"#", "javascript:void(0)", "javascript:void(0);"}
        ):
            targets.append(str(anchor["href"]))
        for tag in (image, anchor, image.parent):
            if tag and tag.get("onclick"):
                targets.extend(
                    unquote(match.group(1)) for match in OPEN_URL.finditer(str(tag["onclick"]))
                )
        src = urljoin(base_url, str(image.get("src", image.get("data-src", ""))))
        for target in targets:
            joined = urljoin(base_url, target)
            candidates.append(joined)
            try:
                image_host = urlsplit(src).hostname
                target_host = urlsplit(joined).hostname
                if image_host == TRUST_HOST and target_host == TRUST_HOST:
                    image_args = {
                        key.lower(): val for key, val in parse_qs(urlsplit(src).query).items()
                    }
                    link_args = {
                        key.lower(): val for key, val in parse_qs(urlsplit(joined).query).items()
                    }
                    if any(
                        image_args.get(key)
                        and link_args.get(key)
                        and image_args[key] != link_args[key]
                        for key in ("id", "code")
                    ):
                        offline.append(
                            Finding(
                                "seal_identifier_mismatch",
                                "شناسه/کد تصویر اینماد با شناسه/کد پیوند اعتبارسنجی آن یکی نیست؛ احتمال کپی یا جابه‌جایی نماد وجود دارد.",
                                "badge HTML",
                            )
                        )
            except ValueError:
                pass
    for anchor in soup.find_all("a", href=True):
        href = str(anchor["href"])
        if "trustseal.enamad" in href.lower():
            candidates.append(urljoin(base_url, href))
    for url in script_urls:
        if "trustseal.enamad" in url.lower():
            candidates.append(urljoin(base_url, url))
    # Fixed onclick URLs may exist on containers or script-generated badge openers.
    for tag in soup.find_all(onclick=True):
        for match in OPEN_URL.finditer(str(tag["onclick"])):
            url = unquote(match.group(1))
            if "trustseal.enamad" in url.lower():
                candidates.append(urljoin(base_url, url))
    return list(dict.fromkeys(candidates)), bool(badges), offline


async def check_enamad(page: Page, fetcher: Fetcher) -> CheckResult:
    warnings = []
    findings = local_phishing_findings(page)
    findings.extend(getattr(fetcher, "frame_phishing_findings", ()))
    links, badge_present, offline = collect_seals(page, getattr(fetcher, "seal_urls", ()))
    findings.extend(offline)
    if (
        not links
        and not findings
        and any(term in page.text for term in ("سامانه ثنا", "سهام عدالت", "ابلاغیه"))
    ):
        warnings.append(
            "نبود اینماد در سامانه‌های دولتی به‌تنهایی نشانهٔ فیشینگ نیست؛ دامنه و فرم‌های صفحه جدا بررسی می‌شوند."
        )
    if urlsplit(page.url).scheme == "http":
        warnings.append("صفحه با HTTP دریافت شد؛ نبود رمزنگاری به‌تنهایی اثبات فیشینگ نیست.")
    partial = False
    verified = 0
    if badge_present and not links:
        partial = True
        warnings.append(
            "نشان اینماد دیده شد، ولی پیوند اعتبارسنجی قابل استخراج نیست؛ نماد تأیید نشده است."
        )
    if len(links) > 3:
        partial = True
        warnings.append("فقط سه پیوند متمایز اینماد بررسی شد.")
    host = (urlsplit(page.url).hostname or "").removeprefix("www.")
    for link in links[:3]:
        try:
            seal_url = normalize_url(link)
        except FetchError:
            partial = True
            warnings.append("پیوند نماد قابل دریافت نیست.")
            continue
        parsed = urlsplit(seal_url)
        if parsed.hostname != TRUST_HOST:
            findings.append(
                Finding(
                    "seal_unofficial_host",
                    "پیوند نشان اینماد به میزبان رسمی trustseal.enamad.ir اشاره نمی‌کند.",
                    "badge target",
                )
            )
            continue
        if parsed.scheme != "https" or parsed.port not in {None, 443}:
            partial = True
            warnings.append("پیوند نماد از HTTPS استاندارد استفاده نمی‌کند و تأیید نشد.")
            continue
        if parsed.path.lower().endswith(("logo.aspx", ".png", ".jpg", ".svg", ".webp")):
            partial = True
            warnings.append("پیوند کلیکِ نماد به تصویر اشاره می‌کند؛ تصویر، صفحهٔ اعتبارسنجی نیست.")
            continue
        try:
            reference = await fetcher.get(seal_url, allowed_host=TRUST_HOST)
        except FetchError:
            partial = True
            warnings.append(
                "مرجع اینماد قابل استعلام نبود؛ اصالت نماد نامشخص است. شواهد محلی صفحه مستقل از این خطا بررسی شده‌اند."
            )
            continue
        registered = reference_domains(reference.text)
        if registered and host not in registered:
            findings.append(
                Finding(
                    "seal_domain_mismatch",
                    "دامنهٔ ثبت‌شده در فیلد دامنهٔ مرجع اینماد با دامنهٔ این صفحه تطابق ندارد؛ احتمال استفاده از نماد متعلق به سایت دیگر وجود دارد.",
                    "official domain field",
                )
            )
            continue
        if not registered:
            partial = True
            warnings.append(
                "فیلد دامنه در مرجع اینماد قابل استخراج نبود؛ ذکر نام سایت در متن عادی برای تأیید کافی نیست."
            )
            continue
        reference_text = BeautifulSoup(reference.text, "html.parser").get_text(" ", strip=True)
        if re.search(r"وضعیت\s*(?:نماد)?\s*[:：]?\s*(?:تعلیق|لغو|منقضی|ابطال)", reference_text):
            findings.append(
                Finding(
                    "seal_inactive_status",
                    "در وضعیت نمادِ مرجع، تعلیق/لغو/انقضا دیده شد؛ نماد فعال تأیید نمی‌شود.",
                    "official status field",
                )
            )
        else:
            verified += 1
    coverage = f"{len(links[:3])} پیوند نماد؛ {verified} تطبیق فیلد دامنه" + (
        "؛ استعلام ناقص" if partial else ""
    )
    if findings:
        return CheckResult(
            Status.SUSPICIOUS,
            findings[0].description,
            tuple(dict.fromkeys(warnings)),
            tuple(findings),
            coverage,
        )
    if partial:
        return CheckResult(
            Status.INCONCLUSIVE,
            "اصالت نماد در این بررسی تأیید نشد؛ دریافت/پوشش مرجع کامل نبود.",
            tuple(dict.fromkeys(warnings)),
            coverage=coverage,
        )
    if verified:
        return CheckResult(
            Status.NOT_DETECTED,
            "دامنه در فیلد مرجع اینماد تطبیق داشت؛ این تطبیق امنیت کل سایت را تضمین نمی‌کند.",
            tuple(warnings),
            coverage=coverage,
        )
    return CheckResult(
        Status.NOT_DETECTED,
        "در صفحهٔ قابل خواندن، فرم درگاه تقلیدی یا پیوند جعلی اینماد شناسایی نشد؛ نبود نماد به‌تنهایی نشانهٔ فیشینگ نیست.",
        tuple(warnings),
        coverage=coverage,
    )
