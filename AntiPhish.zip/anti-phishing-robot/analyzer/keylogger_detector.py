"""Collect bounded scripts and frames; inspect AST data flow without execution."""

import asyncio
import re
from collections import deque
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from analyzer.http_client import Fetcher, FetchError
from analyzer.javascript_analysis import analyze_sources
from analyzer.models import CheckResult, Finding, Page, Status
from analyzer.page_signals import challenge_page, input_metadata, local_phishing_findings

OBFUSCATED = re.compile(
    r"\beval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k|(?:\\x[0-9a-f]{2}){10,}", re.I
)


def strip_comments(source: str) -> str:
    """Compatibility helper; behavioral rules use AST nodes instead of this regex."""
    tokens = re.compile(r"(['\"`])(?:\\.|(?!\1)[\s\S])*?\1|/\*[\s\S]*?\*/|//[^\r\n]*")
    return tokens.sub(lambda match: match.group(0) if match.group(0)[0] in "'\"`" else " ", source)


def analyze_script(source: str) -> tuple[bool, list[str]]:
    """Compatibility API for tests and small standalone script snippets."""
    result = analyze_sources([("inline", source)])
    warnings = list(result.warnings)
    if OBFUSCATED.search(source):
        warnings.append("جاوااسکریپت مبهم دیده شد؛ مبهم‌سازی به‌تنهایی اثبات بدافزار نیست.")
    if result.findings:
        return True, [result.findings[0].description] + warnings
    return False, warnings


def collect_scripts(page):
    soup = BeautifulSoup(page.text, "html.parser")
    base = soup.find("base", href=True)
    base_url = urljoin(page.url, str(base["href"])) if base else page.url
    inline, external = [], []
    for index, script in enumerate(soup.find_all("script"), 1):
        kind = str(script.get("type", "")).lower().strip()
        if kind not in {
            "",
            "module",
            "text/javascript",
            "application/javascript",
            "application/ecmascript",
            "text/ecmascript",
        }:
            continue
        if script.get("src"):
            external.append(urljoin(base_url, str(script["src"])))
        else:
            inline.append((f"inline-{index}", script.get_text()))
    for index, tag in enumerate(soup.find_all(True), 1):
        for attr, value in tag.attrs.items():
            if attr.lower().startswith("on") and isinstance(value, str):
                # Preserve the actual event type and this-element selector for inline handlers.
                selector = str(tag.get("id", ""))
                source = (
                    f"document.getElementById({selector!r}).{attr} = function(event) {{ {value} }};"
                )
                inline.append((f"handler-{index}", source))
    return soup, base_url, inline, list(dict.fromkeys(external))


async def check_keylogger(page: Page, fetcher: Fetcher) -> CheckResult:
    warnings, findings = [], []
    partial = False
    fetched = scripts = frames = 0
    frame_queue = deque([page])
    visited_frames = {page.url}
    script_cache = {}
    script_names = {}
    external_limit = fetcher.settings.max_external_scripts
    frame_limit = getattr(fetcher.settings, "max_frames", 2)
    fetcher.seal_urls = []
    fetcher.frame_phishing_findings = []
    while frame_queue:
        current = frame_queue.popleft()
        if challenge_page(current):
            partial = True
            warnings.append("به‌جای محتوای اصلی، صفحهٔ کنترل دسترسی/ضدبات دریافت شد.")
            continue
        if current is not page:
            fetcher.frame_phishing_findings.extend(
                Finding(
                    item.rule, "در یک iframe دریافت‌شده: " + item.description, "frame HTML inputs"
                )
                for item in local_phishing_findings(current)
            )
        soup, base_url, sources, external = collect_scripts(current)
        metadata = input_metadata(soup)
        analysis = await asyncio.to_thread(analyze_sources, sources, current.url, metadata)
        if analysis.findings:
            fetcher.keylogger_partial = CheckResult(
                Status.SUSPICIOUS,
                analysis.findings[0].description,
                tuple(analysis.warnings) + ("تحلیل تکمیلی فایل‌ها/فریم‌ها هنوز کامل نشده است.",),
                tuple(analysis.findings),
                "تحلیل محلی جاوااسکریپت",
            )
        warnings.extend(analysis.warnings)
        partial |= analysis.partial
        pending = deque(external)
        document_scripts = set()
        # Static import URLs are followed within the same external-file budget.
        for path in analysis.imports:
            if path.startswith(("./", "../", "/", "https://", "http://")):
                pending.append(urljoin(base_url, path))
            else:
                partial = True
                warnings.append("یک import با مسیر نامشخص/ماژولی قابل دریافت مستقیم نبود.")
        while pending:
            url = pending.popleft()
            if url in document_scripts:
                continue
            document_scripts.add(url)
            if url not in script_cache:
                if fetched >= external_limit:
                    partial = True
                    warnings.append("بعضی فایل‌های جاوااسکریپت به دلیل محدودیت تعداد بررسی نشدند.")
                    continue
                fetched += 1
                script_names[url] = f"external-{fetched}"
                try:
                    script_cache[url] = await fetcher.get(url, kind="script")
                except FetchError:
                    script_cache[url] = None
            script = script_cache[url]
            if script is None:
                partial = True
                warnings.append("حداقل یک فایل جاوااسکریپت قابل دریافت نبود.")
                continue
            sources.append((script_names[url], script.text))
            parsed = await asyncio.to_thread(
                analyze_sources, [(script_names[url], script.text)], current.url, metadata
            )
            for path in parsed.imports:
                if path.startswith(("./", "../", "/", "https://", "http://")):
                    pending.append(urljoin(script.url, path))
                else:
                    partial = True
                    warnings.append("یک import با مسیر نامشخص/ماژولی قابل دریافت مستقیم نبود.")
        # Analyze scripts together so values can move across script tags and helpers.
        analysis = await asyncio.to_thread(analyze_sources, sources, current.url, metadata)
        decoded_seen = set()
        for depth in range(2):
            decoded = [code for code in analysis.decoded_programs if code not in decoded_seen][:4]
            if not decoded:
                break
            for code in decoded:
                decoded_seen.add(code)
                sources.append((f"decoded-{depth + 1}-{len(decoded_seen)}", code))
            analysis = await asyncio.to_thread(analyze_sources, sources, current.url, metadata)
        scripts += len(sources)
        findings.extend(analysis.findings)
        if findings:
            fetcher.keylogger_partial = CheckResult(
                Status.SUSPICIOUS,
                findings[0].description,
                tuple(dict.fromkeys(warnings))
                + ("تحلیل تکمیلی فایل‌ها/فریم‌ها هنوز کامل نشده است.",),
                tuple(findings),
                f"{scripts} بخش جاوااسکریپت",
            )
        warnings.extend(analysis.warnings)
        partial |= analysis.partial
        if current is page:
            fetcher.seal_urls.extend(analysis.open_urls)
        for source_name, source in sources:
            if (
                OBFUSCATED.search(source)
                or len(set(re.findall(r"_0x[0-9a-f]+", source, re.I))) > 10
            ):
                partial = True
                warnings.append(
                    "کد مبهم/پویا دیده شد؛ تحلیل ایستا ممکن است همه رفتارهای آن را پوشش ندهد."
                )
        for frame in soup.find_all(["iframe", "frame"]):
            if frames >= frame_limit:
                partial = True
                warnings.append("بعضی iframeها به دلیل محدودیت تعداد بررسی نشدند.")
                continue
            if frame.get("srcdoc"):
                frames += 1
                frame_queue.append(Page(current.url, str(frame["srcdoc"])))
                continue
            if not frame.get("src"):
                partial = True
                warnings.append("iframe پویا بدون آدرس قابل دریافت دیده شد.")
                continue
            url = urljoin(base_url, str(frame["src"]))
            if url in visited_frames:
                continue
            visited_frames.add(url)
            frames += 1
            try:
                frame_queue.append(await fetcher.get(url))
            except FetchError:
                partial = True
                warnings.append("محتوای یک iframe قابل دریافت نبود.")
    findings = list({(f.rule, f.location): f for f in findings}.values())
    warnings = list(dict.fromkeys(warnings))
    coverage = f"{scripts} بخش جاوااسکریپت؛ {fetched} تلاش دریافت فایل خارجی؛ {frames} iframe"
    if findings:
        return CheckResult(
            Status.SUSPICIOUS, findings[0].description, tuple(warnings), tuple(findings), coverage
        )
    if partial:
        return CheckResult(
            Status.INCONCLUSIVE,
            "پوشش تحلیل جاوااسکریپت کامل نبود؛ نمی‌توان نبود خروج اطلاعات را تأیید کرد.",
            tuple(warnings),
            coverage=coverage,
        )
    return CheckResult(
        Status.NOT_DETECTED,
        "در کد قابل تحلیل، مسیر مشخصی از دادهٔ حساس/کلیدهای کیبورد به ارسال شبکه پیدا نشد.",
        tuple(warnings),
        coverage=coverage,
    )
