"""Fetch the main page once and preserve partial evidence on scan timeouts."""

import asyncio
import logging
import time
from urllib.parse import urlsplit

from analyzer.enamad_checker import check_enamad
from analyzer.http_client import Fetcher, FetchError, normalize_url
from analyzer.keylogger_detector import check_keylogger
from analyzer.models import CheckResult, ScanResult, Status
from analyzer.page_signals import challenge_page, local_phishing_findings
from config import Settings

logger = logging.getLogger(__name__)


async def scan_url(url: str, settings: Settings) -> ScanResult:
    started = time.monotonic()
    unknown = CheckResult(
        Status.INCONCLUSIVE, "بررسی کامل نشد؛ امنیت یا فیشینگ بودن قابل تأیید نیست."
    )
    phishing = keylogger = unknown
    errors = []
    fetcher = Fetcher(settings)
    try:
        url = normalize_url(url)
        async with asyncio.timeout(settings.scan_timeout):
            async with fetcher:
                page = await fetcher.get(url)
                if challenge_page(page):
                    raise FetchError("challenge_page")
                local_findings = local_phishing_findings(page)
                if local_findings:
                    phishing = CheckResult(
                        Status.SUSPICIOUS,
                        local_findings[0].description,
                        (
                            "استعلام مرجع نماد هنوز کامل نشده است؛ این نتیجه بر شواهد محلی صفحه استوار است.",
                        ),
                        tuple(local_findings),
                        "HTML محلی",
                    )
                # Scan local scripts first so a slow trust-seal server cannot hide obvious evidence.
                keylogger = await check_keylogger(page, fetcher)
                phishing = await check_enamad(page, fetcher)
    except FetchError as exc:
        errors.append(exc.code)
    except TimeoutError:
        errors.append("scan_timeout")
    except Exception as exc:
        # Never log arbitrary exception text: it can contain URLs, tokens, or page content.
        logger.error("Unexpected scan error: %s", type(exc).__name__)
        errors.append("internal_error")
    errors.extend(fetcher.errors)
    if keylogger.status == Status.INCONCLUSIVE and hasattr(fetcher, "keylogger_partial"):
        keylogger = fetcher.keylogger_partial
    frame_findings = [
        item
        for item in getattr(fetcher, "frame_phishing_findings", ())
        if item not in phishing.findings
    ]
    if frame_findings:
        phishing = CheckResult(
            Status.SUSPICIOUS,
            phishing.reason
            if phishing.status == Status.SUSPICIOUS
            else frame_findings[0].description,
            phishing.warnings,
            phishing.findings + tuple(frame_findings),
            phishing.coverage or "HTML فریم‌های دریافت‌شده",
        )
    elapsed = int((time.monotonic() - started) * 1000)
    result = ScanResult(url, phishing, keylogger, elapsed, tuple(dict.fromkeys(errors)))
    try:
        host = urlsplit(url).hostname or "invalid"
    except ValueError:
        host = "invalid"
    logger.info(
        "Scan completed host=%s status=%s phishing=%s keylogger=%s rules=%s elapsed_ms=%s errors=%s failures=%s",
        host,
        result.status,
        phishing.status,
        keylogger.status,
        ",".join(sorted({f.rule for f in phishing.findings + keylogger.findings})) or "none",
        elapsed,
        ",".join(result.errors) or "none",
        ",".join(fetcher.error_context) or "none",
    )
    return result
