<div align="center">

![Iran Phishing Radar](docs/banner.svg)

# 🛡 Iran Phishing Radar | رادار فیشینگ ایرانی

**A lightweight Telegram bot for suspicious link analysis**  
**بات سبک تلگرام برای بررسی نشانه‌های مشکوک در لینک‌ها**

![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white)
![aiogram](https://img.shields.io/badge/aiogram-3.31-229ED9?logo=telegram&logoColor=white)
![HTTP](https://img.shields.io/badge/HTTP-Direct-2ee6bc)
![Analysis](https://img.shields.io/badge/Analysis-JavaScript_AST-8B5CF6)
![Monitoring](https://img.shields.io/badge/Monitoring-SQLite-003B57?logo=sqlite)
![License](https://img.shields.io/badge/License-MIT-blue)

[فارسی](#فارسی) · [English](#english) · [Debug report](docs/DEBUG_REPORT.md) · [Future dataset](docs/DATASET_IDEA.md)

</div>

---

## فارسی

### ✨ این بات چه می‌کند؟

لینک یا پیام مشکوک را برای بات بفرست. بات **مستقیماً از سرور خودت** صفحه را دریافت می‌کند، پیوندهای اینماد و بخشی از جاوااسکریپت را بررسی می‌کند و نتیجه‌ای خوانا می‌فرستد. هیچ Cloudflare Worker، واسط دریافت صفحه، مرورگر خودکار یا مدل یادگیری ماشین لازم نیست.

| قابلیت | رفتار |
|---|---|
| دریافت مستقیم | صفحه اصلی فقط یک‌بار دریافت و بین تحلیلگرها استفاده می‌شود |
| بررسی اینماد | میزبان رسمی، شناسه/کد تصویر و پیوند، فیلد دامنه و وضعیت نماد در مرجع |
| فرم درگاه تقلیدی | درخواست شماره کارت همراه CVV2 در صفحه‌ای خارج از دامنهٔ شاپرک، مستقل از استعلام اینماد |
| مسیر خروج اطلاعات | parser ساختاری و ردیابی تقریبی داده میان متغیر، callback، تابع واسط و FormData |
| منابع ورودی | کلیدهای کیبورد، مقدار فرم، اطلاعات کارت، رمز عبور و کلیپ‌بورد |
| جاوااسکریپت خارجی | حداکثر ۴ دریافت در کل اسکن؛ مسیر نسبی، `base` و import قابل تعیین |
| iframe | حداکثر ۲ فریم؛ تحلیل جداگانهٔ جاوااسکریپت و فرم درگاه، شامل `srcdoc` |
| شواهد و پوشش | علت هشدار، بخش‌های بررسی‌شده و دلیل ناقص ماندن اسکن |
| نتیجه شفاف | «مشکوک»، «موردی یافت نشد» یا «بررسی نامشخص» |
| مانیتورینگ سبک | دستورهای مدیر، تاریخچه SQLite و لاگ چرخشی انگلیسی |
| محدودیت منابع | زمان، حجم پاسخ، تعداد لینک، هم‌زمانی و فاصله درخواست هر کاربر |

> **مرز نتیجه:** این ابزار تحلیلگر ایستا و مبتنی بر قواعد است. نشانهٔ مشکوک، اثبات قطعی جرم یا کی‌لاگر نیست؛ نبود نشانه نیز تضمین امنیت نیست. خطای شبکه، گواهی نامعتبر، 403 و نبود اینماد به‌تنهایی برچسب فیشینگ ایجاد نمی‌کنند.

### 🚀 نصب و اجرا

پیش‌نیاز: **Python 3.11 یا جدیدتر**؛ این نسخه با Python 3.12 بررسی شده است. روی لینوکس ممکن است بستهٔ `python3-venv` هم لازم باشد.

از نسخهٔ اصلاح‌شدهٔ این پروژه استفاده کن. فایل‌های ZIP را استخراج کن و وارد پوشه‌ای شو که `main_bot.py` در آن است. سپس یکی از مسیرهای زیر را اجرا کن.

**Linux / macOS**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
```

**Windows — CMD**

```bat
py -3 -m venv .venv
.venv\Scripts\activate.bat
python -m pip install -r requirements.txt
copy .env.example .env
```

**Windows — PowerShell**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

اگر PowerShell فعال‌سازی را مسدود کرد، با CMD کار کن یا مستقیماً `.\.venv\Scripts\python.exe` را به جای `python` اجرا کن؛ فعال‌سازی برای اجرای محیط مجازی اجباری نیست.

فایل `.env` را ویرایش کن:

```dotenv
BOT_TOKEN=YOUR_NEW_BOT_TOKEN
ADMIN_IDS=YOUR_NUMERIC_TELEGRAM_USER_ID
```

سپس اجرا:

```bash
python main_bot.py
```

`python main.py` هم همان بات را اجرا می‌کند. توکن یا شبکهٔ تلگرام نامعتبر باشد، اتصال واقعی برقرار نمی‌شود؛ فقط یک نمونه از بات را با همین توکن اجرا کن. اگر قبلاً webhook تنظیم کرده‌ای، قبل از استفاده از polling آن را از تنظیمات/API تلگرام حذف کن.

> **توکن قبلی را تعویض کن:** در نسخهٔ اصلی رپو، توکن بات به‌صورت عمومی قرار گرفته بود. از BotFather آن را revoke کن و توکن جدید بگیر. حذف از فایل فعلی، توکن قبلی را از تاریخچهٔ Git پاک نمی‌کند. در این نسخه توکن واقعی وجود ندارد و `.env` وارد Git نمی‌شود.

### 🔄 ارتقا از نسخهٔ قبلی

بات را متوقف کن، فایل‌های نسخهٔ جدید را جایگزین کن و فایل `.env` و پوشه‌های `data/` و `logs/` خودت را نگه دار. در محیط مجازی فعال، dependencyهای جدید را نصب کن:

```bash
python -m pip install -r requirements.txt
python main_bot.py
```

اگر با systemd اجرا می‌کنی، پس از نصب dependencyها، سرویس تنظیم‌شدهٔ خودت را restart کن. `.env` در ZIP نیست و clone هم آن را نمی‌سازد؛ برای نصب تازه از `.env.example` کپی بگیر. در لینوکس با `ls -la` فایل‌های نقطه‌دار دیده می‌شوند.

برای سروری که استعلام نماد کند است، می‌توانی `REQUEST_TIMEOUT=15` و `SCAN_TIMEOUT=60` را در `.env` تنظیم کنی؛ افزایش زمان انتظار، مسدود بودن مرجع یا صفحهٔ ضدبات را حل نمی‌کند. شواهد محلیِ پیدا‌شده در timeout حفظ می‌شوند.

### 🧠 روش تشخیص نسخهٔ جدید

تحلیلگر JavaScript با Tree-sitter کد را parse می‌کند و مسیر احتمالی داده را تا `fetch`، `sendBeacon`، XHR، WebSocket، URL تصویر و فراخوانی‌های متداول jQuery/axios دنبال می‌کند. تابع نام‌دار، arrow، alias، بافر کلیدها و ارسال با timer پوشش دارند. رشته‌های ثابتِ hex/base64 و بدنهٔ ثابت `eval`/`Function` در حد منابع تعیین‌شده باز و parse می‌شوند؛ **هیچ کدی اجرا نمی‌شود**.

مرجع اینماد جدا بررسی می‌شود: صرف دیدن لوگو یا اسم سایت در متن مرجع، تأیید نیست. timeout مرجع به معنی جعل نیست و شواهد فرم پرداخت را هم حذف نمی‌کند. دامنهٔ شاپرک تنها از قاعدهٔ «درگاه خارج از دامنه» مستثناست؛ تحلیل کیبورد و کلیپ‌بورد همچنان اجرا می‌شود.

| نمونهٔ سورس دریافت‌شده در 2026-10-09 | شواهد در بازپخش محلی |
|---|---|
| `adl-iran.netlify.app` | فرم شماره کارت + CVV2 + رمز دوم خارج از شاپرک؛ در اسکریپت فعلی ارسال اطلاعات پیدا نشد |
| `zerohex.ir/Silent/` | مسیر ورودی کارت → توابع واسط → FormData → fetch؛ کلیپ‌بورد → ارسال شبکه |

در هر دو نمونه نتیجهٔ کلی مشکوک است. این جدول گزارش snapshot است، نه حکم دائمی دربارهٔ دامنه. در کد هیچ شرط اختصاصی برای نام این دو سایت وجود ندارد. اصالت اینماد نمونهٔ اول، هنگام در دسترس نبودن مرجع، نامشخص می‌ماند.

### 📊 پنل مدیر داخل تلگرام

داشبورد وب یا سرویس اضافی لازم نیست. در گفت‌وگوی خصوصی با بات:

| دستور | کاربرد |
|---|---|
| `/start` | معرفی بات |
| `/help` | راهنمای ارسال لینک و معنی نتیجه‌ها |
| `/myid` | نمایش شناسهٔ عددی خودت برای تنظیم `ADMIN_IDS` |
| `/status` | زمان اجرای پردازش، تعداد کارهای فعال، شمارنده‌ها و میانگین زمان |
| `/recent` | ۱۰ بررسی اخیر با دامنه، زمان، وضعیت و مدت بررسی |
| `/errors` | ۱۰ بررسی اخیر دارای خطای دریافت/تحلیل |

برای دریافت شناسه، بات را با `ADMIN_IDS=` خالی اجرا کن، `/myid` را بفرست، عدد را داخل `.env` قرار بده و بات را دوباره اجرا کن. چند مدیر را با ویرگول جدا کن. دستورهای مدیر فقط برای همان شناسه‌ها و در گفت‌وگوی خصوصی کار می‌کنند.

- شمارنده‌ها در SQLite بعد از restart حفظ می‌شوند؛ زمان اجرا و تعداد درخواست‌های ردشده مربوط به اجرای فعلی‌اند.
- فقط **۱۰٬۰۰۰ بررسی اخیر** نگه داشته می‌شود؛ شمارنده‌های تجمعی حفظ می‌شوند. زمان تاریخچه UTC است.
- تاریخچه فقط دامنه، وضعیت دو تحلیلگر، زمان بررسی و کد خطا را ذخیره می‌کند. متن پیام، توکن، مسیر و query لینک یا سورس صفحه ذخیره نمی‌شود.
- این تاریخچه **دیتاست آموزش مدل نیست**. بات ادعا نمی‌کند که لینک گزارش‌شده وارد دیتاست شده است.
- لاگ برنامه در `logs/bot.log` با سه نسخهٔ چرخشی یک‌مگابایتی نگه داشته می‌شود. متن لاگ‌ها انگلیسی است؛ شناسهٔ قواعد تشخیص و مرحله/میزبان خطا هم ثبت می‌شوند.

### ⚙️ تنظیمات

تمام تنظیمات در `.env.example` آمده‌اند؛ متغیرهای محیطی سرور بر `.env` اولویت دارند.

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `BOT_TOKEN` | الزامی | توکن جدید بات |
| `ADMIN_IDS` | خالی | شناسه‌های عددی مدیر؛ خالی یعنی مانیتورینگ تلگرامی غیرفعال |
| `REQUEST_TIMEOUT` | `10` | ثانیه برای یک دریافت و زنجیره redirect آن |
| `SCAN_TIMEOUT` | `40` | سقف ثانیه برای کل بررسی یک لینک |
| `MAX_CONCURRENT_SCANS` | `3` | تعداد درخواست‌های بررسی فعال؛ درخواست اضافی فوراً رد می‌شود |
| `MAX_URLS_PER_MESSAGE` | `3` | حداکثر لینک بررسی‌شده در هر پیام |
| `USER_COOLDOWN_SECONDS` | `5` | فاصلهٔ پذیرش درخواست‌های هر کاربر؛ درخواست هم‌زمان همان کاربر هم رد می‌شود |
| `MAX_EXTERNAL_SCRIPTS` | `4` | سقف فایل‌های خارجی؛ `0` یعنی غیرفعال، همراه گزارش ناقص بودن بررسی |
| `MAX_FRAMES` | `2` | سقف iframe/frame در کل اسکن؛ مقدار مجاز `0` تا `4` |
| `MAX_RESPONSE_BYTES` | `1048576` | سقف حجم **هر پاسخ**: پیش‌فرض یک MiB |
| `MONITOR_DB` | `data/monitor.sqlite3` | مسیر دیتابیس |
| `LOG_LEVEL` | `INFO` | سطح لاگ برنامه |

در حالت پیش‌فرض تنها پورت‌های عمومی `80` و `443` مجازند. آدرس خصوصی، loopback، metadata سرور و DNS دارای IP داخلی مسدود می‌شوند. مقصد redirect و اسکریپت‌های خارجی هم بررسی می‌شود. اعتبار TLS غیرفعال نشده و proxy محیطی استفاده نمی‌شود. سایت‌هایی که خودشان پشت CDN هستند همچنان مستقیم از آدرس اصلی دریافت می‌شوند؛ هیچ Worker واسطی در مسیر نیست.

### 🧪 بررسی کد و تست‌ها

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python -m ruff check .
python -m pip check
```

تست‌ها محلی و با پاسخ‌های مصنوعی‌اند؛ به سایت فیشینگ واقعی یا بات واقعی درخواست نمی‌فرستند. تست یکپارچهٔ تلگرام هم با session ساختگی، چند لینک و دسترسی مدیر را بررسی می‌کند. جزئیات تغییرها در [گزارش دیباگ](docs/DEBUG_REPORT.md) آمده است.

### 🗂 نقشهٔ پروژه

| فایل | مسئولیت |
|---|---|
| `main_bot.py` | دریافت پیام، استخراج لینک، کنترل ظرفیت، پاسخ و دستورهای مدیر |
| `main.py` | نقطهٔ اجرای جایگزین |
| `config.py` | بارگذاری و اعتبارسنجی تنظیمات |
| `analyzer/http_client.py` | دریافت مستقیم، TLS، DNS، redirect و سقف حجم |
| `analyzer/enamad_checker.py` | بررسی پیوند اینماد |
| `analyzer/keylogger_detector.py` | تحلیل ایستای نشانه‌های خروج ورودی |
| `analyzer/javascript_analysis.py` | parser ساختاری و ردیابی تقریبی مسیر داده |
| `analyzer/page_signals.py` | تشخیص نوع ورودی، فرم درگاه تقلیدی و صفحهٔ ضدبات |
| `analyzer/scanner.py` | هماهنگی تحلیلگرها و حفظ شواهد در timeout |
| `analyzer/models.py` | مدل‌های نتیجه و وضعیت |
| `monitoring.py` | تاریخچه و شمارنده‌های SQLite |
| `tests/` | تست‌های دریافت، تحلیل، رابط و یکپارچگی |
| `deploy/anti-phishing-robot.service` | نمونهٔ اختیاری اجرای دائمی با systemd |

### 🔎 محدودیت‌های فعلی

این ابزار مرورگر نیست و جاوااسکریپت را اجرا نمی‌کند. ردیابی داده تقریبی و بدون مدل‌سازی کامل ترتیب اجراست؛ مسیر غیرقابل اجرا هم ممکن است مشکوک شود و helperهای ناشناخته، importهای پیچیده، workerها، WebAssembly، کد ساخته‌شده در زمان اجرا و مبهم‌سازی سنگین ممکن است پوشش ناقص داشته باشند. سایت مبتنی بر JavaScript که HTML اولیه‌اش فرم واقعی را ندارد، به تحلیل مرورگر نیاز دارد. نشانهٔ جست‌وجوی معمولی به‌تنهایی هشدار نیست؛ قابلیت‌های مشروع ثبت ورودی یا ارسال کلیپ‌بورد همچنان نیازمند بازبینی انسانی‌اند.

محدودیت منابع: در هر تحلیل ساختاری حداکثر ۲ MiB کد، ۶۰٬۰۰۰ گره، ۵۰۰٬۰۰۰ عملیات و ۱۲ تکرار. رسیدن به سقف منابع، خطای syntax، کد پویا یا فایل دریافت‌نشده نتیجهٔ ناقص می‌سازد؛ وجود شاهد قوی، وضعیت مشکوک را حفظ می‌کند. «موردی یافت نشد» فقط بخش‌های دریافت‌شده و قابل تحلیل را پوشش می‌دهد.

لوگوی بدون ویژگی قابل تشخیص، badge کاملاً پویا و فیلد دامنهٔ تغییرکردهٔ مرجع ممکن است استخراج نشوند. پیوند نماد در صفحهٔ اصلی بررسی می‌شود؛ نمادهای داخل iframe اعتبارسنجی مستقل ندارند. صفحهٔ ضدبات، مرجع captchaدار، پاسخ خالی/باینری/بزرگ یا پاسخ فشردهٔ اجباری بررسی کامل نمی‌شوند. این قواعد برای زمینهٔ پرداخت ایرانی تنظیم شده‌اند؛ سایت پرداخت خارجی ممکن است به بازبینی زمینه نیاز داشته باشد. دقت روی دیتاست برچسب‌خورده اندازه‌گیری نشده است.

برای اجرای دائمی، نمونهٔ [systemd](deploy/anti-phishing-robot.service) را با مسیر و کاربر واقعی سرورت تنظیم کن. راهنمای کوتاه داخل فایل است. برای ایدهٔ دیتاست ایرانی آینده، [این یادداشت](docs/DATASET_IDEA.md) را بخوان؛ جمع‌آوری و مدل هنوز پیاده‌سازی نشده‌اند.

---

## English

### ✨ What it does

Send the bot a suspicious URL or forwarded message. Your server fetches the page **directly**, checks eNamad seal links, and inspects a bounded subset of JavaScript for possible input exfiltration. No intermediary Worker, browser automation, ML model, or dashboard service is required.

| Feature | Behavior |
|---|---|
| Direct fetching | Main page fetched once and reused by both analyzers |
| Trust-seal checks | Official host, image/link identifiers, labeled reference domain and inactive status |
| Payment impersonation | Card number plus CVV2 inputs outside the Iranian payment gateway domain |
| Input exfiltration | AST parsing and approximate data flow through variables, helpers, callbacks and FormData |
| Input sources | Keyboard keys, form values, payment fields, passwords and clipboard |
| External JavaScript | Up to four fetch attempts per scan, including resolvable imports and HTML `base` |
| Frames | Up to two frames, including `srcdoc`; separate JS context and local payment-form evidence |
| Evidence and coverage | Findings, analyzed sections and incomplete-check explanations |
| Explicit results | `suspicious`, `not_detected`, or `inconclusive` |
| Lightweight monitoring | Private admin commands, SQLite history, rotating English logs |
| Bounded resources | Time, body size, per-message URL limits, concurrency and per-user cooldown |

> **Interpretation:** This is a static, rule-based analyzer. Suspicion is not a confirmed keylogger verdict, and no detected signal is not a safety guarantee. Network errors, HTTP 403, missing seals, and invalid certificates do not independently establish phishing.

### 🚀 Quick start

Use **Python 3.11+**; this revision was tested with Python 3.12. Extract the revised ZIP and enter the directory containing `main_bot.py`. On Linux, install `python3-venv` if your distribution requires it.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
```

On Windows CMD:

```bat
py -3 -m venv .venv
.venv\Scripts\activate.bat
python -m pip install -r requirements.txt
copy .env.example .env
```

On PowerShell, activate with `.\.venv\Scripts\Activate.ps1` and copy with `Copy-Item .env.example .env`. If activation is blocked, use CMD or invoke `.\.venv\Scripts\python.exe` directly.

Edit `.env`:

```dotenv
BOT_TOKEN=YOUR_NEW_BOT_TOKEN
ADMIN_IDS=YOUR_NUMERIC_TELEGRAM_USER_ID
```

Start polling:

```bash
python main_bot.py
```

`python main.py` is an equivalent entry point. Run one polling process per token. Remove any previously configured Telegram webhook before starting polling.

**Rotate the original token:** The upstream repository exposed a bot credential. Revoke it with BotFather and use a new token. Removing the current source value does not remove it from Git history. This revision contains no real token and ignores `.env` in Git.

### 🔄 Upgrade

Stop the bot, replace the application files, and preserve your existing `.env`, `data/` and `logs/`. Activate your virtual environment, install the updated dependencies and restart:

```bash
python -m pip install -r requirements.txt
python main_bot.py
```

For systemd, restart your configured service after installing dependencies. The ZIP and Git clone do not include a populated `.env`; copy `.env.example` only on fresh installs. Linux displays dotfiles with `ls -la`.

For slow seal servers, `REQUEST_TIMEOUT=15` and `SCAN_TIMEOUT=60` are optional. Longer waits do not solve network blocks or anti-bot challenges. Already discovered local evidence survives timeouts.

### 🧠 Analysis approach

Tree-sitter parses JavaScript. A bounded, approximate data-flow engine follows sensitive sources through aliases, named callbacks, arrows, buffers, helpers and FormData to fetch, Beacon, XHR, WebSocket, image URLs and common jQuery/axios calls. Constant hex/base64 strings and bounded literal eval/Function bodies are parsed **without executing code**.

Seal verification is independent: a logo or incidental domain mention is insufficient. An unavailable reference cannot establish forgery or erase local payment-form evidence. The Shaparak host exception affects only the local gateway rule; keyboard and clipboard analysis still runs.

| Downloaded source snapshot, 2026-10-09 | Local replay evidence |
|---|---|
| `adl-iran.netlify.app` | Card + CVV2 + payment OTP outside Shaparak; no transfer found in the current application script |
| `zerohex.ir/Silent/` | Card inputs → helpers → FormData → fetch; clipboard contents → network |

Both snapshots produce a suspicious overall verdict without rules targeting their domain names. This is snapshot evidence, not a permanent domain verdict. The first site's seal remains unverified when the official reference is unavailable. See [the debug report](docs/DEBUG_REPORT.md) for replay scope.

### 📊 Admin monitoring

| Command | Purpose |
|---|---|
| `/start` | Introduction |
| `/help` | Submission guide and result meanings |
| `/myid` | Your numeric Telegram user ID |
| `/status` | Process uptime, active work, cumulative counters and mean scan time |
| `/recent` | Ten latest scans: host, UTC timestamp, verdict and duration |
| `/errors` | Ten latest retained scans with fetch/analysis error codes |

Start with empty `ADMIN_IDS`, send `/myid` privately, add the returned ID to `.env`, and restart. Separate multiple admin IDs with commas. Admin commands require both an allowlisted sender and a private chat. An empty allowlist disables them.

SQLite preserves cumulative scan counters across restarts and retains the latest **10,000 scan events**. Uptime and rejected-request counts reset at process startup. Only hostname, analyzer statuses, timing, and stable error codes are stored. No original messages, paths, query strings, page source, or tokens are retained. This history is **not a training dataset**. Application logs include rule identifiers and failing fetch stage/host, with three one-MiB rotated backups at `logs/bot.log`. Telegram responses are Persian; code comments, docstrings and application logs are English.

### ⚙️ Configuration

Process environment values override `.env`. See `.env.example` for all settings.

| Variable | Default | Meaning |
|---|---|---|
| `BOT_TOKEN` | Required | New bot credential |
| `ADMIN_IDS` | Empty | Comma-separated numeric admin IDs |
| `REQUEST_TIMEOUT` | `10` | Seconds per fetch, including redirects |
| `SCAN_TIMEOUT` | `40` | Seconds for the entire URL scan |
| `MAX_CONCURRENT_SCANS` | `3` | Active scan requests; excess work rejected immediately |
| `MAX_URLS_PER_MESSAGE` | `3` | Maximum URLs analyzed per message |
| `USER_COOLDOWN_SECONDS` | `5` | Per-user admission cooldown; overlapping requests also rejected |
| `MAX_EXTERNAL_SCRIPTS` | `4` | External JS file limit; skipped files make the check inconclusive |
| `MAX_FRAMES` | `2` | Total iframe/frame limit; valid values are `0` through `4` |
| `MAX_RESPONSE_BYTES` | `1048576` | Maximum bytes per response |
| `MONITOR_DB` | `data/monitor.sqlite3` | SQLite file location |
| `LOG_LEVEL` | `INFO` | Application logging level |

Only HTTP(S) on ports 80/443 is fetched. Private, loopback, metadata and mixed public/private DNS destinations are rejected, including script and redirect targets. The checked DNS answers are used by the connector, TLS verification remains enabled, and environment proxies are ignored. Websites hosted behind a CDN remain reachable through their original URLs; no intermediary Worker is used.

### 🧪 Development checks

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python -m ruff check .
python -m pip check
```

Tests use synthetic fixtures and mocked network/Telegram responses. They do not contact live phishing sites or a real bot. See the [debug report](docs/DEBUG_REPORT.md) for the scope and verification results.

### 🔎 Current limitations

The engine is not a browser. Its flow-insensitive approximation does not model complete JavaScript execution order, so unreachable paths can trigger findings. Unknown helpers, complex imports, workers, WebAssembly, runtime-generated code and heavy obfuscation can be missed or marked partial. Client-rendered sites without real content in their initial HTML need browser analysis. Ordinary search alone is excluded; legitimate input recording or clipboard transfers still require human review.

Each structural analysis is bounded to 2 MiB, 60,000 nodes, 500,000 evaluation operations and 12 passes. Exhaustion, unsupported dynamic code, syntax errors and unavailable files make coverage incomplete. Strong evidence still yields a suspicious verdict. No-detection applies only to fetched, supported content.

Unmarked or fully dynamic badge images and changed official-reference fields may not be extracted. Seal verification covers the main page, not independent seals inside frames. Challenge pages, captcha-protected references, binary, oversized, empty or forcibly compressed responses prevent complete analysis. Gateway rules target the Iranian payment context and may require review for foreign payment pages. Accuracy has not been benchmarked on a labeled corpus.

Optional Linux service: customize [the systemd example](deploy/anti-phishing-robot.service) for your host. Future Iranian phishing dataset design is described in [this note](docs/DATASET_IDEA.md); no collector or ML training pipeline has been added.

### 📚 References

- [aiogram documentation](https://docs.aiogram.dev/en/latest/)
- [aiohttp client documentation](https://docs.aiohttp.org/en/stable/client_advanced.html)
- [Tree-sitter Python bindings](https://github.com/tree-sitter/py-tree-sitter)
- [Tree-sitter JavaScript grammar](https://github.com/tree-sitter/tree-sitter-javascript)
- [Original repository](https://github.com/mobina-hsz/anti-phishing-robot)

### 📄 License

MIT. The upstream [LICENSE](LICENSE) and attribution are preserved.
