# Debug report | گزارش اصلاح و بررسی

Upstream revision: `63162c7` · Updated: 2026-10-09 · Runtime used: Python 3.12

## فارسی

### تغییرهای اصلی

| ایراد قبلی | اصلاح |
|---|---|
| صفحه و پیوند اینماد با الحاق URL به Worker دریافت می‌شدند | تمام دریافت‌ها از URL اصلی و با یک HTTP client مشترک برای هر بررسی انجام می‌شوند |
| دامنه‌های مشهور از بررسی اصلی معاف می‌شدند | shortcut حذف شد؛ دامنه مشهور هم از مسیر تحلیل معمول عبور می‌کند |
| دو فایل زیرساخت هم‌نام و ناسازگار وجود داشت | هر دو فایل بلااستفاده حذف شدند؛ فراخوانی‌ها و import مربوط هم حذف شدند |
| TLS بدون اعتبارسنجی استفاده می‌شد | اعتبارسنجی TLS فعال است؛ خطای گواهی نتیجه نامشخص دارد |
| هر 403/timeout به فیشینگ تبدیل می‌شد | وضعیت دریافت ناقص از نشانهٔ جعل جدا شد |
| خطای بررسی کی‌لاگر گاهی «امن» گزارش می‌شد | خطا یا اسکریپت دریافت‌نشده نتیجه نامشخص می‌سازد |
| رویداد کیبورد و fetch بی‌ربط در یک فایل کافی بود | ساختار AST و مسیر تقریبی داده از منبع ورودی تا ارسال شبکه بررسی می‌شود |
| جاوااسکریپت خارجی و handler داخل HTML دیده نمی‌شد | فایل خارجی محدود، مسیر نسبی، base و handlerهای متداول اضافه شدند |
| نمونه‌کد داخل رشته و comment باعث هشدار می‌شد | parser رشته و comment را از کد اجرایی جدا می‌کند؛ بدنهٔ ثابت eval/Function جدا parse می‌شود |
| ساخت XMLHttpRequest بدون ارسال کافی بود | ارسال `.send(...)` بررسی می‌شود؛ صرف ساخت XHR کافی نیست |
| Packer/hex یا API تلگرام اثبات کی‌لاگر محسوب می‌شد | این موارد به‌تنهایی هشدار توضیحی‌اند |
| میزبان نماد با substring بررسی می‌شد | میزبان رسمی باید دقیقاً `trustseal.enamad.ir` باشد؛ redirect مرجع هم به همان میزبان محدود است |
| تطبیق دامنه با substring بود | مرز دامنه کنترل می‌شود؛ `fake-shop.ir` با `shop.ir` یکسان نیست |
| نبود نماد در سامانهٔ دولتی باعث فیشینگ می‌شد | نبود نماد به‌تنهایی حکم فیشینگ ایجاد نمی‌کند |
| توکن واقعی داخل کد بود | بارگذاری از `.env`/environment؛ توکن واقعی در خروجی وجود ندارد |
| نتیجه چند لینک روی یک پیام بازنویسی می‌شد | هر لینک پیام وضعیت و نتیجهٔ جداگانه دارد |
| HTML خروجی از URL خام ساخته می‌شد | متن‌های متغیر escape و طول نمایش محدود می‌شود؛ preview لینک هم غیرفعال است |
| ادعای ذخیرهٔ آموزشی بدون ذخیره‌سازی وجود داشت | حذف ادعا؛ تاریخچهٔ واقعی مانیتورینگ با دامنه و وضعیت ذخیره می‌شود |
| `main.py` فقط آزمایش SSL بود | حالا نقطهٔ اجرای معتبر بات است |
| requirements و راهنمای کافی نبود | requirements اجرای اصلی/توسعه، README دوزبانه، نمونه env و systemd اضافه شدند |
| فایل‌های pyc داخل Git بودند | فایل‌های کامپایل‌شده حذف و ignore شدند |

### اصلاح اسکنرها در نسخهٔ دوم

| شکاف تشخیص | اصلاح و مرز نتیجه |
|---|---|
| timeout مرجع اینماد شواهد فرم درگاه را پنهان می‌کرد | شماره کارت همراه CVV2 خارج از دامنهٔ شاپرک پیش از شبکه بررسی می‌شود؛ جعل خود نماد همچنان مستقل است |
| ارسال از تابع واسط یا بعد از تایمر دیده نمی‌شد | ردیابی تقریبی ورودی/کلید از alias، بافر، پارامتر، return و FormData تا sink شبکه |
| داده میان چند script جابه‌جا می‌شد | تحلیل مشترک فایل‌ها در هر سند؛ namespace مشترک scriptها و scope جدا برای توابع |
| ارسال کلیپ‌بورد تشخیص داده نمی‌شد | readText و callbackهای Promise تا ارسال شبکه دنبال می‌شوند |
| badge با onclick یا شناسهٔ متفاوت دیده نمی‌شد | استخراج onclick و opener ثابت؛ تطبیق id/Code تصویر و پیوند |
| ذکر اتفاقی نام دامنه در مرجع کافی بود | فقط فیلد دامنهٔ قابل استخراج/برچسب‌خورده برای تطبیق استفاده می‌شود |
| کد ناقص، import یا iframe نادیده می‌ماند | importهای قابل تعیین و دو فریم در بودجهٔ محدود؛ موارد بررسی‌نشده وضعیت ناقص می‌سازند |
| script مشترک فریم با ورودی‌های صفحهٔ اصلی تحلیل می‌شد | یک دریافت، ولی تحلیل جدا با metadata ورودی‌های هر سند |
| نتیجهٔ سالم از صفحهٔ ضدبات برمی‌گشت | challenge شناخته‌شده، محتوای واقعی محسوب نمی‌شود |
| تابع void یا console.log می‌توانست خروجی حساس ساختگی بسازد | return تابع محلی از بدنه استخراج می‌شود؛ برای log و پاسخ شبکه return حساس اختراع نمی‌شود |
| OTP ورود با دادهٔ کارت اشتباه می‌شد | OTP به‌تنهایی قاعدهٔ ارسال اطلاعات کارت را فعال نمی‌کند |
| timeout فقط یک کد کلی داشت | لاگ انگلیسی شامل شناسهٔ قواعد و مرحله/میزبان دریافت ناموفق است؛ URL کامل ثبت نمی‌شود |

Tree-sitter فقط parse می‌کند؛ هیچ script، eval یا Function اجرا نمی‌شود. پردازش ثابت hex/base64 و بدنهٔ ثابت کد پویا حداکثر دو لایه انجام می‌شود. ردیابی داده flow-insensitive و context-insensitive است و اثبات اجرای واقعی محسوب نمی‌شود. محدودیت‌ها و بودجه‌ها در README آمده‌اند.

### بازپخش دو نمونهٔ گزارش‌شده

سورس صفحه‌های گزارش‌شده با GET دریافت و به تحلیلگر جدید به‌صورت پاسخ ذخیره‌شده داده شد. هیچ فرم ارسال نشد و هیچ دسترسی دوربین، میکروفون یا کلیپ‌بورد درخواست نشد. فایل‌های واقعی صفحات و مقادیر بالقوهٔ حساس آن‌ها در بستهٔ تحویلی قرار نگرفته‌اند.

| snapshot | شواهد قابل مشاهده |
|---|---|
| `adl-iran.netlify.app` | فرم شماره کارت، CVV2 و رمز دوم/پویا خارج از دامنهٔ شاپرک؛ در `script.js` فعلی مسیر ارسال اطلاعات پیدا نشد |
| `zerohex.ir/Silent/` | ورودی‌های کارت → submitForm → FormData → postFD/fetchRetry → fetch؛ کلیپ‌بورد → postJSON → ارسال شبکه |

هر دو snapshot نتیجهٔ کلی مشکوک دارند. نام این دامنه‌ها در قواعد تشخیص شرط نشده است. در نمونهٔ دوم، مسیر اطلاعات کارت و کلیپ‌بورد شاهد اصلی است؛ وجود کی‌لاگر مبتنی بر keydown در snapshot ادعا نمی‌شود. مرجع اینماد نمونهٔ اول از این محیط timeout داشت، بنابراین کپی بودن/اصالت خود نماد تأیید نشد. نمونهٔ اول با فرم درگاه مستقل از این خطا تشخیص داده می‌شود. تغییر بعدی سورس یا پاسخ متفاوت سرور می‌تواند نتیجه را عوض کند.

### مانیتورینگ

`/status`، `/recent` و `/errors` فقط برای شناسه‌های مدیر در گفت‌وگوی خصوصی فعال‌اند. SQLite تاریخچهٔ محدود به ۱۰٬۰۰۰ بررسی و شمارنده‌های تجمعی را حفظ می‌کند. لاگ‌ها انگلیسی، چرخشی و بدون query لینک یا متن exception خام‌اند. تاریخچه، دیتاست آموزشی محسوب نمی‌شود. داشبورد وب یا dependency پایش جداگانه اضافه نشده است.

### نتیجهٔ بررسی‌ها

| بررسی | نتیجه |
|---|---|
| `python -m pytest -q` | **128 passed** |
| `python -m ruff check .` | بدون خطا |
| `python -m compileall` روی فایل‌های برنامه و تست | موفق |
| `python -m pip check` | No broken requirements found |
| بررسی کد برنامه برای Worker endpoint و غیرفعال‌سازی TLS | موردی وجود ندارد |
| بررسی کد برنامه برای توکن بات جاسازی‌شده | توکن واقعی وجود ندارد |
| تست یکپارچه HTTP با سرور محلی | دریافت مستقیم، redirect، فایل JS و نتیجهٔ مشکوک موفق |
| تست یکپارچه Telegram با session ساختگی | پاسخ جداگانهٔ چند لینک و اجازهٔ مدیر موفق |
| بازپخش سورس دو نمونهٔ گزارش‌شده | شواهد درگاه تقلیدی در اولی و ارسال کارت/کلیپ‌بورد در دومی پیدا شد |
| دریافت مرجع اینماد نمونهٔ اول | timeout در این محیط؛ اصالت نماد نامشخص |
| مسیر اینترنتی production روی سرور کاربر | اجرا نشد؛ بازپخش جای آزمایش end-to-end سرور را نمی‌گیرد |
| polling روی Telegram واقعی | اجرا نشد؛ توکن افشاشده استفاده نشد |

تست‌ها عملکرد مسیرهای اصلاح‌شده را بررسی می‌کنند؛ دقت تشخیص روی مجموعهٔ واقعی فیشینگ ایرانی اندازه‌گیری نشده است. این خروجی را روی سرورت با توکن جدید راه‌اندازی و چند نمونهٔ سالم و مصنوعی بررسی کن. سیاست شبکهٔ سرور، دسترسی به تلگرام و مرجع اینماد می‌تواند بر نتیجهٔ دریافت اثر بگذارد.

### تغییر رابط داخلی

تحلیلگرها دیگر tuple بولی برنمی‌گردانند. `check_enamad(page, fetcher)` و `check_keylogger(page, fetcher)` یک `CheckResult` با status/reason/warnings/findings/coverage می‌دهند. هر Finding شامل شناسهٔ قاعده، توضیح و محل عمومی شاهد است. برای استفاده از بیرون بات، `await scan_url(url, settings)` رابط اصلی است و `ScanResult` می‌دهد. این تغییر برای جداکردن «نامشخص» از «بدون نشانه» لازم بود.

### کار باقی‌مانده برای آینده

مدل ML، crawler، دیتاست و تحلیل مرورگر پیاده‌سازی نشده‌اند. پیشنهاد دیتاست در [DATASET_IDEA.md](DATASET_IDEA.md) است. محدودیت‌های detector ایستا در README مستند شده‌اند. تغییرها فقط در نسخهٔ تحویلی اعمال شده‌اند؛ به رپوی GitHub push نشده‌اند. توکن قدیمی در upstream عمومی و تاریخچه آن باقی است و باید از BotFather باطل شود.

---

## English

### Changes

- Removed all intermediary Worker requests and both obsolete infrastructure modules, including the well-known-domain bypass.
- Added a shared per-scan direct HTTP client with verified TLS, checked public DNS answers, revalidated redirects, body/time limits and no environment proxies.
- Introduced explicit suspicious, not-detected and inconclusive results; network failures cannot become safety or phishing verdicts by themselves.
- Replaced callback regex matching with Tree-sitter AST parsing and bounded approximate data flow through aliases, named callbacks, arrows, buffers, helpers, returns and FormData. Scripts in one document share analysis; frames have separate input metadata. XHR construction alone does not establish transmission.
- Downgraded obfuscation and Telegram API presence to standalone warnings. No token values are exposed in scan output.
- Tightened official trust-seal hostname and domain-boundary checks. Missing seals and unavailable reference pages do not prove phishing.
- Fixed independent multi-link responses, hidden-link/UTF-16 extraction, HTML escaping, length limits, session shutdown and the application entry point.
- Moved bot credentials to environment configuration; removed tracked bytecode.
- Added private admin commands, bounded SQLite event history, cumulative counters, rotating English logs, validated settings, runtime/dev requirements, bilingual README and optional systemd sample.
- Added local card-plus-CVV2 gateway evidence outside Shaparak, independent of official-seal availability; keyboard, clipboard and network rules still apply on gateway hosts.
- Added clipboard Promise tracing, resolvable imports, bounded frame/srcdoc inspection, constant encoded/dynamic-code parsing without execution, challenge-page handling, evidence and coverage reports.
- Improved seal click-target extraction, id/Code consistency and labeled reference-domain/status checks. Frame opener URLs are not incorrectly verified against the parent site's domain.
- Fixed false taint propagation from void/logging/network return values and kept standalone login OTP out of card-exfiltration rules.

### Verification

**128 tests passed** on Python 3.12. Ruff, compile checks and `pip check` passed. Tests cover conservative detector decisions, exact seal-host/domain matching, public/private address checks, redirect blocking, response limits, scan outcomes, URL entities, admission limits, monitoring persistence, multiple Telegram responses and admin authorization. Additional regressions cover helper chains, cross-script FormData, clipboard, transport aliases, encoded keys/code, import/frame limits, repeated scripts across frame contexts, benign OTP/search/logging, challenge responses and preservation of strong evidence after timeouts.

An actual local HTTP fixture validated the direct request/redirect/script transport. Its resolver is substituted only inside that test; production public-address checks remain enabled. Telegram integration uses an in-memory fake session and never uses a real credential.

The reported pages were downloaded by HTTP GET and replayed as stored fetch responses. The first snapshot contains a card/CVV2/payment-OTP form outside Shaparak; its current application script has no detected data-transfer path. The second contains card data flowing through submitForm/FormData/postFD/fetchRetry to fetch, plus clipboard-to-network flow. Both produce suspicious overall results without domain-specific detection rules. Literal keyboard logging is not claimed for the second snapshot.

The first seal's official reference timed out here, so forgery of the seal itself remains unverified. Scripts were not executed, forms were not submitted, and captured sources/tokens are excluded from the deliverable. This replay does not validate the production network path on the user's server. Real Telegram polling was not run; the exposed upstream credential was not used. No accuracy benchmark against a labeled Persian phishing corpus was performed.

### Compatibility and scope

Analyzer functions accept a fetched `Page` plus `Fetcher` and return `CheckResult` with status, reason, warnings, findings and coverage. Use `await scan_url(url, settings)` as the top-level Python API. The data-flow engine is flow-insensitive and context-insensitive; potential paths are not runtime proof. No ML model, dataset collector or browser execution was added. Code limitations and interpretation are documented in README. Preserve `.env`, `data/` and `logs/` when upgrading, install updated requirements and restart. Changes were not pushed to upstream GitHub. Revoke the upstream credential with BotFather before deploying.
